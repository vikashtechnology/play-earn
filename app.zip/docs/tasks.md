# Play & Earn Real Cash — Build Tasks

This plan supersedes the earlier generic task list and follows the current PRD, implementation blueprint, coin economy, fraud, KYC, and support documents. Complete one numbered task at a time and update this file and `memory.md` at each milestone.

## Verified Progress

- [x] Repository, documentation, workspace, and initial API foundation.
- [x] Neon PostgreSQL connection configuration; migration `001_init_schema.sql` applied and API health verified.
- [x] Shared domain declarations and request validation for wallets, offers, payouts, rewards, products, and orders.
- [x] Product order route rejects client-supplied identity/prices and calculates costs from catalog.
- [x] Install offers require a Google Play Store listing URL.
- [x] Android Compose project scaffold, brand name, design token mapping, and API 36 target.
- [x] Android navigation shell for Home, Earn, Rewards, Wallet, and Profile; signed-out balance states and AdMob-only coin messaging are separated.
- [x] OTP challenge schema applied on Neon; OTP API validates Indian phone numbers, stores only hashes, throttles attempts, expires challenges, and issues a short-lived phone-verification token.
- [x] Android OTP phone/code UI, resend/expiry states, API client, and Android Keystore-backed token storage.
- [x] Email-code signup with one-time link fallback, Google ID-token verification with nonce replay protection, versioned consent capture, and Android Credential Manager UI.
- [x] Cash withdrawals require a signed user session plus phone OTP Minimum KYC; the challenge is bound to the same user and the payout endpoint rejects caller-supplied identity/status.
- [x] Neon identity smoke verifies email account/wallet/consent creation, one-time Google nonce consumption, and transactional phone Minimum-KYC persistence; synthetic test records were removed.
- [x] Important cross-cutting feature and release requirements documented.

## Current Task

3. [x] Signup and cash-withdrawal verification: email code/link fallback, Google nonce validation, Android UI, and user-bound phone Minimum-KYC gates are built and Neon-smoke-tested. Provider credentials, DLT approval, OAuth client setup, and reviewed policy URLs/versions remain configuration gates; signup and OTP delivery stay disabled until configured.

## Android MVP

3. [x] Signup and phone verification code: email verification with code/link fallback, Google sign-in, OTP expiry/resend UI, secure session storage, and withdrawal Minimum KYC gate implemented. [ ] Configure live providers, OAuth client, and reviewed policy links before enabling.
4. [ ] Home and profile: API-backed balance/featured content, profile details, referral entry, preferences, and support contacts.
5. [ ] Earn and offers: survey/check-in/brand sections, offer detail and statuses, missing-reward support link, Play Store-only install handoff.
6. [ ] Rewards and wallet: separate coin sources and balances; pending/available/reserved/reversed states; ledger history.
7. [ ] Account deletion: in-app path, confirmation, API workflow, and public web deletion instructions.
8. [ ] Android API client: HTTPS configuration, typed DTOs, request/error handling, session storage, and no provider secrets in APK.

## API and Data

9. [ ] Move API feature routes from in-memory Maps to PostgreSQL repositories and transactions.
10. [ ] Expand schema for user profiles, devices, consent, KYC, coin source, idempotency, expiries, reservations, conversions, campaigns, fraud, support, and webhook events.
11. [x] Add email/Google signup, consent-aware user provisioning, and secure OTP endpoints with expiry/rate limits. [ ] Configure real providers/policies before enabling live signup and SMS delivery.
12. [ ] Implement append-only coin ledger; source-tag every entry; enforce idempotency and atomic reserve/commit/release/reversal.
13. [ ] Enforce AdMob coins as in-app-only and block them from cash/gift-card redemption.
14. [ ] Add signed, replay-safe, idempotent S2S callbacks; validate install referrer and click ID before crediting.
15. [ ] Implement configurable approval windows, earn/redemption limits, and coin expiry; never hard-code production economics.
16. [ ] Add KYC status/tier checks, payout eligibility, provider idempotency, and reconciliation before enabling cash withdrawal.
17. [ ] Implement product checkout with coin reservation, Razorpay payment verification, and fulfillment state machine.

## Admin and Operations

18. [ ] Admin web app with secure sign-in, short-lived sessions, MFA-ready boundary, and no client-side secrets.
19. [ ] RBAC for Super Admin, Operations, Finance, Marketing, Support, Risk, and Analyst.
20. [ ] Review queues for offers, rewards, withdrawals, fraud, orders, and support.
21. [ ] Immutable admin audit log with actor, target, reason, and before/after hashes; dual authorization for sensitive balance adjustments.
22. [ ] Campaign, brand, catalog, reporting, finance, and CMS workflows.
23. [ ] Support ticket API and user views matching `docs/08_Support_SLA.md`; add escalation and grievance contact management.

## Release Gates

24. [ ] Rate limits, webhook signatures/replay protection, fraud rules, device controls, and risk holds.
25. [ ] Provider adapters and sandbox tests for OTP, offerwall, KYC, payouts, gift cards, payments, and notifications.
26. [ ] Structured monitoring, alerts, backups, restore rehearsal, reconciliation jobs, and incident response plan.
27. [ ] Legal/CA review for coins, KYC, cashout, DPDP, tax, GST/TDS, consumer terms, and grievance obligations.
28. [ ] Google Play policy review, Financial features declaration, Data Safety disclosures, deletion URL, Android API 36 validation, VAPT, and closed testing.
29. [ ] Production release only after security, provider, compliance, and operational gates pass.

## Build Notes

- Android Gradle compilation is pending because Gradle is not installed in the current environment.
- Admin Next.js dependencies could not be installed because package fetches stalled; do not claim the admin build passes until dependencies install and tests run.
- Cash payouts remain disabled until KYC and qualified legal/provider review are complete.
- Email signup and Google sign-in are disabled until provider credentials, Google client ID, and reviewed Terms/Privacy URLs/versions are configured; phone OTP delivery is disabled until Fast2SMS credentials and DLT templates are approved.
- Never claim guaranteed income. AdMob rewarded ads grant in-app-only coins; cash/gift-card rewards come only from verified eligible campaigns.
