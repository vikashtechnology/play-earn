import test from 'node:test';
import assert from 'node:assert/strict';

import {
  parseCashWithdrawalRequest,
  parseEmailCodeVerificationRequest,
  parseEmailLinkVerificationRequest,
  parseEmailSignupRequest,
  parseGoogleSignupRequest,
  parseGoogleNonceRequest,
  parseOfferCreateInput,
  parseOtpRequest,
  parseOtpVerificationRequest,
  parsePayoutRequestInput,
  parseProductCreateInput,
  parseProductOrderRequest,
  parseRewardEventInput,
  parseWalletTransactionInput,
} from '../index.js';

test('offer and product schemas normalize defaults and reject invalid values', () => {
  assert.equal(parseOfferCreateInput({ title: 'Survey' }).countryCode, 'IN');
  assert.equal(parseProductCreateInput({ sku: 'sku-1', title: 'Speaker' }).status, 'draft');
  assert.throws(() => parseProductCreateInput({ sku: '', title: 'Speaker' }));
});

test('install offers only accept Google Play Store destinations', () => {
  const offer = parseOfferCreateInput({
    title: 'Partner app install',
    kind: 'install',
    landingUrl: 'https://play.google.com/store/apps/details?id=com.example.partner',
  });

  assert.equal(offer.kind, 'install');
  assert.throws(() => parseOfferCreateInput({
    title: 'External APK',
    kind: 'install',
    landingUrl: 'https://example.com/app.apk',
  }));
  assert.throws(() => parseOfferCreateInput({ title: 'Missing destination', kind: 'install' }));
});

test('wallet and reward schemas reject unsafe amounts', () => {
  assert.equal(parseWalletTransactionInput({ direction: 'credit', amount: 12 }).amount, 12);
  assert.throws(() => parseWalletTransactionInput({ direction: 'credit', amount: 1.5 }));
  assert.throws(() => parseRewardEventInput({ offerId: 'offer-1', rewardCoins: -1 }));
  assert.throws(() => parseRewardEventInput({ offerId: 'offer-1', rewardCoins: 1, status: 'approved' }));
});

test('payout schema restricts supported payout destinations', () => {
  assert.equal(parsePayoutRequestInput({ amount: 100, payoutType: 'upi' }).amount, 100);
  assert.throws(() => parsePayoutRequestInput({ amount: 100, payoutType: 'wallet' }));
});

test('order request rejects client-supplied price or identity fields', () => {
  assert.deepEqual(parseProductOrderRequest({ productSku: 'sku-1', quantity: 2 }), {
    productSku: 'sku-1',
    quantity: 2,
  });
  assert.throws(() => parseProductOrderRequest({ productSku: 'sku-1', coinsSpent: 1, quantity: 2 }));
});

test('OTP schemas normalize Indian numbers and require six digits', () => {
  assert.deepEqual(parseOtpRequest({ phone: '98765 43210' }), { phone: '+919876543210' });
  assert.deepEqual(parseOtpRequest({ phone: '+91 98765-43210' }), { phone: '+919876543210' });
  assert.throws(() => parseOtpRequest({ phone: '12345' }));
  assert.deepEqual(parseOtpVerificationRequest({ phone: '9876543210', code: '123456' }), {
    phone: '+919876543210',
    code: '123456',
  });
  assert.throws(() => parseOtpVerificationRequest({ phone: '9876543210', code: '123' }));
});

test('email signup requires age and policy acceptance and defaults optional consent off', () => {
  const request = parseEmailSignupRequest({
    email: ' Person@Example.com ',
    fullName: 'A Person',
    adultConfirmed: true,
    termsAccepted: true,
    privacyAccepted: true,
  });

  assert.equal(request.email, 'person@example.com');
  assert.equal(request.analyticsOptIn, false);
  assert.equal(request.personalizedOffersOptIn, false);
  assert.throws(() => parseEmailSignupRequest({ email: 'person@example.com', fullName: 'A Person' }));
});

test('email code/link and Google signup requests validate required credentials', () => {
  assert.deepEqual(parseEmailCodeVerificationRequest({ email: 'person@example.com', code: '123456' }), {
    email: 'person@example.com',
    code: '123456',
  });
  assert.deepEqual(parseEmailLinkVerificationRequest({ supabaseAccessToken: 'a.b.c' }), {
    supabaseAccessToken: 'a.b.c',
  });
  assert.throws(() => parseEmailLinkVerificationRequest({ supabaseAccessToken: 'short' }));
  assert.throws(() => parseGoogleSignupRequest({ credential: 'not-a-token' }));
  assert.deepEqual(parseGoogleNonceRequest({
    adultConfirmed: true,
    termsAccepted: true,
    privacyAccepted: true,
  }), { analyticsOptIn: false, personalizedOffersOptIn: false });
});

test('cash withdrawal request requires idempotency and rejects client identity/status', () => {
  assert.deepEqual(parseCashWithdrawalRequest({
    amount: 500,
    payoutType: 'upi',
    idempotencyKey: 'withdraw_request_123456',
  }), {
    amount: 500,
    payoutType: 'upi',
    idempotencyKey: 'withdraw_request_123456',
  });
  assert.throws(() => parseCashWithdrawalRequest({
    amount: 500,
    payoutType: 'upi',
    idempotencyKey: 'withdraw_request_123456',
    userId: 'another-user',
  }));
});