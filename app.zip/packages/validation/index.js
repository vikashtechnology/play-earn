function requireObject(input, allowedFields) {
  if (input === null || typeof input !== 'object' || Array.isArray(input)) {
    throw new TypeError('request body must be an object');
  }

  for (const field of Object.keys(input)) {
    if (!allowedFields.includes(field)) {
      throw new TypeError(`unknown field: ${field}`);
    }
  }

  return input;
}

function readString(input, field, fallback, { required = false, maxLength = Infinity } = {}) {
  const value = input[field] ?? fallback;

  if (typeof value !== 'string') {
    throw new TypeError(`${field} must be a string`);
  }

  const normalized = value.trim();

  if ((required && normalized.length === 0) || normalized.length > maxLength) {
    throw new RangeError(`${field} is missing or too long`);
  }

  return normalized;
}

function readInteger(input, field, fallback, { positive = false, maximum = Number.MAX_SAFE_INTEGER } = {}) {
  const value = input[field] ?? fallback;

  if (!Number.isSafeInteger(value) || value < (positive ? 1 : 0) || value > maximum) {
    throw new RangeError(`${field} must be a ${positive ? 'positive' : 'non-negative'} safe integer`);
  }

  return value;
}

function readEnum(input, field, fallback, values) {
  const value = input[field] ?? fallback;

  if (!values.includes(value)) {
    throw new RangeError(`${field} must be one of: ${values.join(', ')}`);
  }

  return value;
}

export function parseWalletTransactionInput(value) {
  const input = requireObject(value, ['type', 'direction', 'amount', 'reason', 'sourceType', 'sourceId', 'metadata']);
  const sourceId = input.sourceId ?? null;

  if (sourceId !== null && (typeof sourceId !== 'string' || sourceId.trim().length === 0)) {
    throw new TypeError('sourceId must be a non-empty string or null');
  }

  const metadata = input.metadata ?? {};

  if (metadata === null || typeof metadata !== 'object' || Array.isArray(metadata)) {
    throw new TypeError('metadata must be an object');
  }

  return {
    type: readString(input, 'type', 'adjustment', { required: true }),
    direction: readEnum(input, 'direction', undefined, ['credit', 'debit']),
    amount: readInteger(input, 'amount', undefined, { positive: true }),
    reason: readString(input, 'reason', 'manual_adjustment', { required: true }),
    sourceType: readString(input, 'sourceType', 'system', { required: true }),
    sourceId: sourceId?.trim() ?? null,
    metadata,
  };
}

export function parseOfferCreateInput(value) {
  const input = requireObject(value, [
    'provider', 'title', 'description', 'kind', 'payoutCoins', 'countryCode', 'status', 'landingUrl', 'verificationMode',
  ]);
  const landingUrl = input.landingUrl ?? null;

  if (landingUrl !== null) {
    if (typeof landingUrl !== 'string') {
      throw new TypeError('landingUrl must be a URL string or null');
    }

    try {
      new URL(landingUrl);
    } catch {
      throw new TypeError('landingUrl must be a valid absolute URL');
    }
  }

  const countryCode = readString(input, 'countryCode', 'IN', { required: true }).toUpperCase();

  if (!/^[A-Z]{2}$/.test(countryCode)) {
    throw new RangeError('countryCode must be a two-letter country code');
  }

  const kind = readString(input, 'kind', 'offer', { required: true }).toLowerCase();

  if (kind === 'install' && !isPlayStoreInstallUrl(landingUrl)) {
    throw new RangeError('install offers must use a Google Play Store URL');
  }

  return {
    provider: readString(input, 'provider', 'generic', { required: true }),
    title: readString(input, 'title', undefined, { required: true, maxLength: 255 }),
    description: readString(input, 'description', '', { maxLength: 5000 }),
    kind,
    payoutCoins: readInteger(input, 'payoutCoins', 0),
    countryCode,
    status: readEnum(input, 'status', 'draft', ['draft', 'active', 'paused', 'inactive']),
    landingUrl,
    verificationMode: readString(input, 'verificationMode', 'server', { required: true }),
  };
}

function isPlayStoreInstallUrl(value) {
  if (typeof value !== 'string') {
    return false;
  }

  const url = new URL(value);

  return (url.protocol === 'https:'
      && url.hostname === 'play.google.com'
      && url.pathname.startsWith('/store/apps/'))
    || (url.protocol === 'market:'
      && url.hostname === 'details'
      && Boolean(url.searchParams.get('id')));
}

export function parseRewardEventInput(value) {
  const input = requireObject(value, ['offerId', 'rewardCoins']);

  return {
    offerId: readString(input, 'offerId', undefined, { required: true }),
    rewardCoins: readInteger(input, 'rewardCoins', undefined),
  };
}

export function parsePayoutRequestInput(value) {
  const input = requireObject(value, ['amount', 'provider', 'payoutType']);

  return {
    amount: readInteger(input, 'amount', undefined, { positive: true }),
    provider: readString(input, 'provider', 'razorpayx', { required: true }),
    payoutType: readEnum(input, 'payoutType', undefined, ['upi', 'bank']),
  };
}

export function parseProductCreateInput(value) {
  const input = requireObject(value, ['sku', 'title', 'description', 'priceCoins', 'cashAddon', 'status']);

  return {
    sku: readString(input, 'sku', undefined, { required: true, maxLength: 128 }),
    title: readString(input, 'title', undefined, { required: true, maxLength: 255 }),
    description: readString(input, 'description', '', { maxLength: 5000 }),
    priceCoins: readInteger(input, 'priceCoins', 0),
    cashAddon: readInteger(input, 'cashAddon', 0),
    status: readEnum(input, 'status', 'draft', ['draft', 'active']),
  };
}

export function parseProductOrderRequest(value) {
  const input = requireObject(value, ['productSku', 'quantity']);

  return {
    productSku: readString(input, 'productSku', undefined, { required: true, maxLength: 128 }),
    quantity: readInteger(input, 'quantity', 1, { positive: true, maximum: 99 }),
  };
}

export function parseOtpRequest(value) {
  const input = requireObject(value, ['phone']);
  const phone = readString(input, 'phone', undefined, { required: true });
  const digits = phone.replace(/[\s()-]/g, '');
  const nationalNumber = digits.startsWith('+91') ? digits.slice(3) : digits;

  if (!/^[6-9]\d{9}$/.test(nationalNumber)) {
    throw new RangeError('phone must be a valid Indian mobile number');
  }

  return { phone: `+91${nationalNumber}` };
}

export function parseOtpVerificationRequest(value) {
  const input = requireObject(value, ['phone', 'code']);
  const { phone } = parseOtpRequest({ phone: input.phone });
  const code = readString(input, 'code', undefined, { required: true });

  if (!/^\d{6}$/.test(code)) {
    throw new RangeError('code must be a six-digit OTP');
  }

  return { phone, code };
}

export function parseEmailSignupRequest(value) {
  const input = requireObject(value, [
    'email', 'fullName', 'adultConfirmed', 'termsAccepted', 'privacyAccepted',
    'analyticsOptIn', 'personalizedOffersOptIn',
  ]);
  const email = readString(input, 'email', undefined, { required: true, maxLength: 255 }).toLowerCase();
  const fullName = readString(input, 'fullName', undefined, { required: true, maxLength: 255 });

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new RangeError('email must be a valid address');
  }
  if (input.adultConfirmed !== true) {
    throw new RangeError('adult confirmation is required');
  }
  if (input.termsAccepted !== true || input.privacyAccepted !== true) {
    throw new RangeError('Terms and Privacy Notice acceptance is required');
  }
  if (input.analyticsOptIn !== undefined && typeof input.analyticsOptIn !== 'boolean') {
    throw new TypeError('analyticsOptIn must be a boolean');
  }
  if (input.personalizedOffersOptIn !== undefined && typeof input.personalizedOffersOptIn !== 'boolean') {
    throw new TypeError('personalizedOffersOptIn must be a boolean');
  }

  return {
    email,
    fullName,
    analyticsOptIn: input.analyticsOptIn ?? false,
    personalizedOffersOptIn: input.personalizedOffersOptIn ?? false,
  };
}

export function parseEmailCodeVerificationRequest(value) {
  const input = requireObject(value, ['email', 'code']);
  const email = readString(input, 'email', undefined, { required: true, maxLength: 255 }).toLowerCase();
  const code = readString(input, 'code', undefined, { required: true });

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !/^\d{6}$/.test(code)) {
    throw new RangeError('valid email and six-digit code are required');
  }

  return { email, code };
}

export function parseEmailLinkVerificationRequest(value) {
  const input = requireObject(value, ['supabaseAccessToken']);
  const supabaseAccessToken = readString(input, 'supabaseAccessToken', undefined, { required: true, maxLength: 8192 });

  if (supabaseAccessToken.split('.').length !== 3) {
    throw new RangeError('Supabase access token is invalid');
  }

  return { supabaseAccessToken };
}

export function parseGoogleNonceRequest(value) {
  const input = requireObject(value, [
    'adultConfirmed', 'termsAccepted', 'privacyAccepted',
    'analyticsOptIn', 'personalizedOffersOptIn',
  ]);
  if (input.adultConfirmed !== true || input.termsAccepted !== true || input.privacyAccepted !== true) {
    throw new RangeError('adult confirmation, Terms, and Privacy Notice acceptance are required');
  }
  if (input.analyticsOptIn !== undefined && typeof input.analyticsOptIn !== 'boolean') {
    throw new TypeError('analyticsOptIn must be a boolean');
  }
  if (input.personalizedOffersOptIn !== undefined && typeof input.personalizedOffersOptIn !== 'boolean') {
    throw new TypeError('personalizedOffersOptIn must be a boolean');
  }

  return {
    analyticsOptIn: input.analyticsOptIn === true,
    personalizedOffersOptIn: input.personalizedOffersOptIn === true,
  };
}

export function parseGoogleSignupRequest(value) {
  const input = requireObject(value, [
    'credential', 'nonce', 'adultConfirmed', 'termsAccepted', 'privacyAccepted',
    'analyticsOptIn', 'personalizedOffersOptIn',
  ]);
  const credential = readString(input, 'credential', undefined, { required: true, maxLength: 8192 });
  const nonce = readString(input, 'nonce', undefined, { required: true, maxLength: 128 });

  if (credential.split('.').length !== 3) {
    throw new RangeError('Google credential must be an ID token');
  }
  if (input.adultConfirmed !== true || input.termsAccepted !== true || input.privacyAccepted !== true) {
    throw new RangeError('adult confirmation, Terms, and Privacy Notice acceptance are required');
  }

  return {
    credential,
    nonce,
    analyticsOptIn: input.analyticsOptIn === true,
    personalizedOffersOptIn: input.personalizedOffersOptIn === true,
  };
}

export function parseCashWithdrawalRequest(value) {
  const input = requireObject(value, ['amount', 'payoutType', 'idempotencyKey']);
  const idempotencyKey = readString(input, 'idempotencyKey', undefined, { required: true, maxLength: 128 });

  if (!/^[A-Za-z0-9_-]{16,128}$/.test(idempotencyKey)) {
    throw new RangeError('idempotencyKey must contain 16 to 128 safe characters');
  }

  return {
    amount: readInteger(input, 'amount', undefined, { positive: true }),
    payoutType: readEnum(input, 'payoutType', undefined, ['upi', 'bank']),
    idempotencyKey,
  };
}