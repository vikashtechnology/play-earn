# Project Memory

## Project

India Rewards Marketplace

## Status

API foundation and initial feature domains are implemented. Neon connection setup is in place, with live migration verification pending local credentials; production data persistence for feature routes is not yet complete.

## Decisions

-   India-only launch.
-   Android app + backend API + web admin.
-   Internal virtual coin currency.
-   Immutable/auditable wallet ledger.
-   UPI/bank cash redemption where provider/business eligibility allows.
-   Gift cards/vouchers through an approved provider.
-   Physical products may support coins + cash.
-   Monetization through approved partner offers, ads, direct campaigns
    and brand deals.
-   Offer completion must be provider-verified.
-   Provider integrations use adapters.
-   Money/reward-changing admin actions are audited.
-   Play Store compliance is a release gate.

## Constraints

No gambling/betting, fake engagement, fake conversions or
policy-bypassing systems. Do not expose provider secrets to clients.
Payment/business accounts must satisfy applicable age, KYC and legal
requirements.

## Current Task

Next task --- API-backed home/profile and completing the Android account session; email/Google signup and cash-withdrawal Minimum KYC implementation is complete, with external providers still disabled pending configuration.

## To Decide Later

Exact providers, business/legal entity, coin-to-INR economics,
withdrawal minimum, fraud thresholds, product fulfillment and
tax/accounting treatment.

## Change Log

Initial project documentation created.
Repository foundation scaffold created with root workspace, app packages, shared packages, and project documentation index.
Task 1 complete.
Backend environment bootstrap created using a minimal Node API, runtime config, health endpoints, and a working test harness.
Task 2 complete.
Wallet ledger logic implemented with immutable transaction validation, balance derivation, and wallet API endpoints for read/write operations.
Task 11 and Task 12 complete.
Offer domain and API implemented with validation, normalization, eligibility checks, and list/create endpoints for reward offers.
Task 16 and Task 17 complete.
Reward domain and API implemented with referral and offer reward events, status handling, and user reward listing/creation endpoints.
Task 24 complete.
Product catalog and order flow implemented with normalized product creation, coin-plus-cash order rules, and catalog/order endpoints.
Task 30 and Task 31 complete.
Runtime environment loading fixed; API startup now verifies PostgreSQL connectivity. Neon connection templates support a pooled application URL and a direct migration URL.
Task 2 and Task 3 complete. Neon migration `001_init_schema.sql` applied; API connected through the pooled Neon URL and health returned `ok: true`.
Shared domain declarations and strict request parsers added for wallet, offers, rewards, payouts, products, and orders. Order prices and reward approval status are server-controlled inputs.
Task 4 implementation complete and validated.
Product/order routes now enforce the shared product and order parsers; forged order prices and user identity are rejected, and catalog values determine order totals.
Android Kotlin/Jetpack Compose project scaffolded with design.md color/spacing tokens, `Play & Earn Real Cash` branding, a marketplace-first starter screen, and API 36 target. Android build verification pending because Gradle is unavailable in the environment.
Task 5 scaffold complete; compile verification pending.
Added navigable Home, Earn, Rewards, Wallet, and Profile tabs with signed-out states, marketplace-first content, and separate in-app-only AdMob coin messaging.
Added 18+ self-declaration guest gate, under-18 blocked state pending parental verification, separate optional consent preview switches, and delayed-notification messaging. Consent is session-only and account creation remains unavailable until approved policies and server-side consent storage are implemented.
Added PostgreSQL OTP challenges storing phone/code/IP hashes, phone/IP throttling, five-attempt lockout, five-minute expiry, single-use verification, and a short-lived onboarding-only JWT. Android has OTP entry, resend/expiry feedback, API client, and encrypted token storage. OTP delivery is disabled pending a real SMS provider adapter.
OTP migration was applied to Neon; a synthetic challenge insert/verify/delete smoke test passed.
Added Fast2SMS provider adapter with a hard delivery gate, request timeout, India number validation, and provider-failure tests. Real SMS remains disabled until DLT/provider credentials are configured.
Added email code signup with one-time app-link fallback, verified Google ID-token/JWKS validation with single-use nonces, versioned consent storage, and Android Credential Manager integration. Added user-bound phone OTP Minimum KYC and a signed-session cash withdrawal gate. Identity/consent/nonce/phone verification smoke passed against Neon and cleaned up its synthetic records.
Final Neon smoke verified email user/wallet/consent creation, Google nonce single-use behavior, and transactional phone Minimum-KYC timestamps; test identity and nonce were removed afterward. Signup/SMS features remain disabled until real providers, DLT, OAuth, and reviewed public policy URLs are configured.
Neon migration and pooled API health check verified after local configuration; database connection values remain in ignored local env files.
Offer creation now rejects install offers that do not target Google Play Store, with route and shared validation coverage.
