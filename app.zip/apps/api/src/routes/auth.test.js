import test from 'node:test';
import assert from 'node:assert/strict';

import { createApp } from '../app.js';
import { OtpDeliveryError, InvalidOtpError } from '../domain/otp.js';
import { config } from '../config.js';
import { issueAccessToken } from '../security/session.js';

async function requestJson(service, pathname, body, options = {}) {
  const { method = 'POST', ...appOptions } = options;
  const server = createApp({ authService: service, ...appOptions });
  await new Promise((resolve) => server.listen(0, resolve));

  try {
    const { port } = server.address();
    const response = await fetch(`http://127.0.0.1:${port}${pathname}`, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });

    return { status: response.status, body: await response.json() };
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
}

test('OTP request normalizes an Indian phone and does not return an OTP', async () => {
  let requestedPhone;
  const service = {
    async requestOtp(phone) {
      requestedPhone = phone;
      return { expiresInSeconds: 300, resendInSeconds: 60 };
    },
  };
  const result = await requestJson(service, '/api/v1/auth/otp/request', { phone: '98765 43210' });

  assert.equal(result.status, 200);
  assert.equal(requestedPhone, '+919876543210');
  assert.deepEqual(result.body, { ok: true, expiresInSeconds: 300, resendInSeconds: 60 });
});

test('OTP request rejects invalid phone numbers and reports provider outage', async () => {
  const service = {
    async requestOtp() { throw new OtpDeliveryError('not configured'); },
  };
  const invalid = await requestJson(service, '/api/v1/auth/otp/request', { phone: '12345' });
  const unavailable = await requestJson(service, '/api/v1/auth/otp/request', { phone: '9876543210' });

  assert.equal(invalid.status, 400);
  assert.equal(unavailable.status, 503);
});

test('OTP verify validates six digits and maps invalid codes to 401', async () => {
  const service = {
    async verifyOtp() { throw new InvalidOtpError('invalid'); },
  };
  const malformed = await requestJson(service, '/api/v1/auth/otp/verify', {
    phone: '+919876543210',
    code: '123',
  });
  const invalid = await requestJson(service, '/api/v1/auth/otp/verify', {
    phone: '+919876543210',
    code: '123456',
  });

  assert.equal(malformed.status, 400);
  assert.equal(invalid.status, 401);
});

test('withdrawal phone OTP endpoints require a user session and bind challenge to that user', async () => {
  let requestedContext;
  let verifiedContext;
  const userId = 'user-for-phone-kyc';
  const service = {
    async requestOtp(phone, ipHash, context) {
      requestedContext = { phone, context };
      return { expiresInSeconds: 300, resendInSeconds: 60 };
    },
    async verifyOtp(phone, code, context) {
      verifiedContext = { phone, code, context };
      return { minimumKycVerified: true };
    },
  };
  const server = createApp({ authService: service });
  await new Promise((resolve) => server.listen(0, resolve));

  try {
    const { port } = server.address();
    const token = issueAccessToken({ subject: userId, scope: 'user', secret: config.jwtSecret });
    const request = await fetch(`http://127.0.0.1:${port}/api/v1/auth/withdrawal/otp/request`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone: '9876543210' }),
    });
    const requestBody = await request.json();
    const verify = await fetch(`http://127.0.0.1:${port}/api/v1/auth/withdrawal/otp/verify`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone: '9876543210', code: '123456' }),
    });
    const verifyBody = await verify.json();

    assert.equal(request.status, 200);
    assert.equal(requestBody.expiresInSeconds, 300);
    assert.deepEqual(requestedContext, {
      phone: '+919876543210',
      context: { userId, purpose: 'withdrawal' },
    });
    assert.equal(verify.status, 200);
    assert.equal(verifyBody.minimumKycVerified, true);
    assert.equal(verifiedContext.context.userId, userId);
    assert.equal(verifiedContext.context.purpose, 'withdrawal');
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
});

test('email signup route is disabled unless providers and published policies are configured', async () => {
  const service = { async requestOtp() {} };
  const disabled = await requestJson(service, '/api/v1/auth/email/signup', {
    email: 'person@example.com',
    fullName: 'Person',
    adultConfirmed: true,
    termsAccepted: true,
    privacyAccepted: true,
  });
  const policies = await requestJson(service, '/api/v1/auth/policies', undefined, { method: 'GET' });

  assert.equal(disabled.status, 503);
  assert.equal(policies.status, 200);
  assert.equal(policies.body.emailSignupEnabled, false);
});

test('email signup route passes consent and reports code/link delivery method', async () => {
  let signupInput;
  const identity = {
    async requestEmailSignup(input) {
      signupInput = input;
      return { deliveryMethod: 'link', expiresInSeconds: 600, emailHint: 'p***@example.com' };
    },
  };
  const result = await requestJson({ async requestOtp() {} }, '/api/v1/auth/email/signup', {
    email: 'person@example.com',
    fullName: 'Person',
    adultConfirmed: true,
    termsAccepted: true,
    privacyAccepted: true,
    analyticsOptIn: false,
    personalizedOffersOptIn: true,
  }, {
    identityService: identity,
    authConfig: {
      signupEnabled: true,
      emailProvider: 'resend',
      emailProviderApiKey: 'configured-test-key',
      emailFallbackApiKey: 'configured-test-fallback-key',
      emailFrom: 'verify@example.com',
      termsVersion: 'terms-v1',
      privacyVersion: 'privacy-v1',
      termsUrl: 'https://example.com/terms',
      privacyUrl: 'https://example.com/privacy',
    },
  });

  assert.equal(result.status, 202);
  assert.equal(result.body.deliveryMethod, 'link');
  assert.equal(signupInput.personalizedOffersOptIn, true);
  assert.equal(signupInput.analyticsOptIn, false);
});
