import { config } from '../config.js';
import { verifyAccessToken } from '../security/session.js';
import { listOffers } from './offers.js';
import { getWalletForUser } from './wallet.js';

function sendJson(res, statusCode, body) {
  res.writeHead(statusCode, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(body));
}

function getOptionalSession(req, verifyToken = (token) => verifyAccessToken(token, config.jwtSecret, { scope: 'user' })) {
  const authorization = req.headers.authorization ?? '';
  const tokenMatch = authorization.match(/^Bearer\s+(.+)$/i);

  return tokenMatch ? verifyToken(tokenMatch[1]) : null;
}

function buildBalanceSummary(userId) {
  if (!userId) {
    return {
      availableCoins: 0,
      pendingCoins: 0,
      reservedCoins: 0,
      reversedCoins: 0,
      adMobInAppCoins: 0,
    };
  }

  const wallet = getWalletForUser(userId);

  return wallet.transactions.reduce((summary, transaction) => {
    const signedAmount = transaction.direction === 'credit' ? transaction.amount : -transaction.amount;
    const status = String(transaction.status ?? '').toLowerCase();
    const sourceType = String(transaction.sourceType ?? '').toLowerCase();

    if (sourceType === 'admob') {
      summary.adMobInAppCoins += signedAmount;
    } else if (status === 'pending') {
      summary.pendingCoins += signedAmount;
    } else if (status === 'reserved') {
      summary.reservedCoins += Math.abs(transaction.amount);
    } else if (status === 'reversed') {
      summary.reversedCoins += Math.abs(transaction.amount);
    } else {
      summary.availableCoins += signedAmount;
    }

    return summary;
  }, {
    availableCoins: 0,
    pendingCoins: 0,
    reservedCoins: 0,
    reversedCoins: 0,
    adMobInAppCoins: 0,
  });
}

function featuredContent() {
  return listOffers().slice(0, 3).map((offer) => ({
    id: offer.id,
    title: offer.title,
    description: offer.description,
    kind: offer.kind,
    rewardCoins: offer.rewardCoins,
  }));
}

export async function handleHomeProfileRoute(req, res, pathname, dependencies = {}) {
  const session = getOptionalSession(req, dependencies.verifyToken);
  const userId = session?.sub ?? null;

  if (req.method === 'GET' && pathname === '/api/v1/home') {
    sendJson(res, 200, {
      signedIn: Boolean(userId),
      userId,
      balances: buildBalanceSummary(userId),
      featured: featuredContent(),
      sections: [
        { id: 'surveys', title: 'Surveys', supporting: 'Partner tasks with clear reward conditions.' },
        { id: 'brand_rewards', title: 'Brand rewards', supporting: 'Sponsored campaigns and promotions.' },
        { id: 'catalog', title: 'Products and vouchers', supporting: 'Rewards available through approved providers.' },
      ],
    });
    return;
  }

  if (req.method === 'GET' && pathname === '/api/v1/profile') {
    sendJson(res, 200, {
      signedIn: Boolean(userId),
      user: userId ? {
        id: userId,
        email: typeof session.email === 'string' ? session.email : null,
        fullName: typeof session.full_name === 'string' ? session.full_name : null,
        emailVerified: session.email_verified === true,
        phoneVerified: session.phone_verified === true,
      } : null,
      referral: userId ? {
        code: `PEARN-${userId.slice(0, 8).toUpperCase()}`,
        status: 'preview',
      } : null,
      preferences: {
        analyticsOptIn: false,
        personalizedOffersOptIn: false,
        notificationsEnabled: false,
      },
      support: {
        email: 'support@example.com',
        categories: ['offers', 'payouts', 'rewards', 'orders'],
      },
      accountDeletion: {
        available: false,
        status: 'Account deletion workflow is a release gate.',
      },
    });
    return;
  }

  sendJson(res, 404, { ok: false, error: 'home/profile route not found' });
}
