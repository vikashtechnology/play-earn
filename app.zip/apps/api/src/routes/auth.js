import { createHmac } from 'node:crypto';

import {
  parseEmailCodeVerificationRequest,
  parseEmailLinkVerificationRequest,
  parseEmailSignupRequest,
  parseGoogleSignupRequest,
  parseGoogleNonceRequest,
  parseOtpRequest,
  parseOtpVerificationRequest,
} from '@rewards-platform/validation';
import { createIdentityRepository } from '../db/identityRepository.js';
import { pool } from '../db.js';
import { config } from '../config.js';
import { createVerificationEmailSenders } from '../services/resendEmail.js';
import { createSupabaseAuthClient } from '../services/supabaseAuth.js';
import {
  createIdentityService,
  EmailDeliveryUnavailableError,
  IdentityRateLimitError,
  InvalidVerificationError,
} from '../domain/identity.js';
import { verifyAccessToken } from '../security/session.js';

// Legacy OTP service — kept for the generic /api/v1/auth/otp/* endpoints until
// Supabase phone auth fully replaces them.
import { createOtpRepository } from '../db/otpRepository.js';
import {
  createOtpService,
  InvalidOtpError,
  OtpDeliveryError,
  OtpRateLimitError,
} from '../domain/otp.js';

const otpService = createOtpService({
  repository: createOtpRepository(pool),
  otpHashSecret: config.otpHashSecret,
  jwtSecret: config.jwtSecret,
  deliveryEnabled: false,
  sendOtp: async () => { throw new OtpDeliveryError('Use Supabase Auth for OTP delivery'); },
});

const supabaseAuth = createSupabaseAuthClient({
  url: config.supabaseUrl,
  anonKey: config.supabaseAnonKey,
  serviceRoleKey: config.supabaseServiceRoleKey,
});

const emailSenders = createVerificationEmailSenders({
  primaryApiKey: '',
  fallbackApiKey: config.emailFallbackApiKey,
  from: config.emailFrom,
});

const identityService = createIdentityService({
  repository: createIdentityRepository(pool),
  supabaseAuth,
  sendFallbackLink: emailSenders.sendFallbackLink,
  challengeSecret: config.otpHashSecret,
  jwtSecret: config.jwtSecret,
  verificationBaseUrl: config.emailVerificationLinkBase,
  termsVersion: config.termsVersion,
  privacyVersion: config.privacyVersion,
});

function hasPublishedPolicies(authConfig = config) {
  return Boolean(authConfig.termsVersion && authConfig.privacyVersion && authConfig.termsUrl && authConfig.privacyUrl);
}

function isEmailSignupEnabled(authConfig = config) {
  return authConfig.signupEnabled
    && authConfig.authProvider === 'supabase'
    && authConfig.supabaseAuthEnabled
    && Boolean(authConfig.supabaseUrl && authConfig.supabaseAnonKey && authConfig.supabaseServiceRoleKey)
    && hasPublishedPolicies(authConfig)
    && Boolean(authConfig.emailFallbackApiKey && authConfig.emailFrom);
}

function isGoogleSignupEnabled(authConfig = config) {
  return authConfig.authProvider === 'supabase'
    && authConfig.supabaseAuthEnabled
    && Boolean(authConfig.supabaseUrl && authConfig.supabaseAnonKey && authConfig.supabaseServiceRoleKey)
    && authConfig.googleSignInEnabled
    && hasPublishedPolicies(authConfig)
    && Boolean(authConfig.googleWebClientId);
}

function sendIdentityError(res, error, fallbackMessage) {
  if (error instanceof IdentityRateLimitError || (error instanceof Error && error.message === 'EMAIL_RATE_LIMITED')) {
    sendJson(res, 429, { error: 'Too many verification attempts. Please wait and try again.' });
  } else if (error instanceof InvalidVerificationError) {
    sendJson(res, 401, { error: error.message });
  } else if (error instanceof EmailDeliveryUnavailableError) {
    sendJson(res, 503, { error: error.message });
  } else if (error instanceof TypeError || error instanceof RangeError) {
    sendJson(res, 400, { error: error.message });
  } else {
    sendJson(res, 500, { error: fallbackMessage });
  }
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];

    req.on('data', (chunk) => chunks.push(chunk));
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
      } catch {
        reject(new TypeError('invalid JSON body'));
      }
    });
    req.on('error', reject);
  });
}

function hashIpAddress(address) {
  if (!address) {
    return null;
  }

  return createHmac('sha256', config.otpHashSecret).update(address).digest('hex');
}

function sendJson(res, statusCode, body) {
  res.writeHead(statusCode, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(body));
}

function getUserSession(req) {
  const authorization = req.headers.authorization ?? '';
  const match = authorization.match(/^Bearer\s+(.+)$/i);
  return match ? verifyAccessToken(match[1], config.jwtSecret, { scope: 'user' }) : null;
}

export async function handleAuthRoute(
  req,
  res,
  pathname,
  service = otpService,
  identity = identityService,
  authConfig = config,
) {
  if (req.method === 'GET' && pathname === '/api/v1/auth/policies') {
    sendJson(res, 200, {
      signupEnabled: isEmailSignupEnabled(authConfig),
      emailSignupEnabled: isEmailSignupEnabled(authConfig),
      googleSignInEnabled: isGoogleSignupEnabled(authConfig),
      termsUrl: authConfig.termsUrl || null,
      privacyUrl: authConfig.privacyUrl || null,
      termsVersion: authConfig.termsVersion || null,
      privacyVersion: authConfig.privacyVersion || null,
    });
    return;
  }

  if (req.method === 'POST' && pathname === '/api/v1/auth/email/signup') {
    if (!isEmailSignupEnabled(authConfig)) {
      sendJson(res, 503, { error: 'Email signup is unavailable until email delivery and published policies are configured.' });
      return;
    }

    try {
      const input = parseEmailSignupRequest(await readBody(req));
      const result = await identity.requestEmailSignup(input, hashIpAddress(req.socket.remoteAddress));
      sendJson(res, 202, { ok: true, ...result });
    } catch (error) {
      sendIdentityError(res, error, 'Unable to start signup verification.');
    }
    return;
  }

  if (req.method === 'POST' && pathname === '/api/v1/auth/email/verify') {
    if (!isEmailSignupEnabled(authConfig)) {
      sendJson(res, 503, { error: 'Email signup is unavailable until email delivery and published policies are configured.' });
      return;
    }

    try {
      const input = parseEmailCodeVerificationRequest(await readBody(req));
      sendJson(res, 200, { ok: true, ...await identity.verifyEmailCode(input.email, input.code) });
    } catch (error) {
      sendIdentityError(res, error, 'Unable to verify email.');
    }
    return;
  }

  if (req.method === 'POST' && pathname === '/api/v1/auth/email/verify-link') {
    if (!isEmailSignupEnabled(authConfig)) {
      sendJson(res, 503, { error: 'Email signup is unavailable until email delivery and published policies are configured.' });
      return;
    }

    try {
      const { supabaseAccessToken } = parseEmailLinkVerificationRequest(await readBody(req));
      sendJson(res, 200, { ok: true, ...await identity.verifyEmailLink(supabaseAccessToken) });
    } catch (error) {
      sendIdentityError(res, error, 'Unable to verify email link.');
    }
    return;
  }

  if (req.method === 'POST' && pathname === '/api/v1/auth/google/nonce') {
    if (!isGoogleSignupEnabled(authConfig)) {
      sendJson(res, 503, { error: 'Google sign-in is unavailable until configured.' });
      return;
    }

    try {
      const consent = parseGoogleNonceRequest(await readBody(req));
      sendJson(res, 200, await identity.createGoogleNonce(hashIpAddress(req.socket.remoteAddress), consent));
    } catch (error) {
      if (error instanceof IdentityRateLimitError) {
        sendJson(res, 429, { error: 'Too many Google sign-in requests. Please wait and try again.' });
        return;
      }
      sendJson(res, 500, { error: 'Unable to start Google sign-in.' });
    }
    return;
  }

  if (req.method === 'POST' && pathname === '/api/v1/auth/google/verify') {
    if (!isGoogleSignupEnabled(authConfig)) {
      sendJson(res, 503, { error: 'Google sign-in is unavailable until configured.' });
      return;
    }

    try {
      const input = parseGoogleSignupRequest(await readBody(req));
      const result = await identity.signInWithGoogle(
        input.credential,
        input.nonce,
      );
      sendJson(res, 200, { ok: true, ...result });
    } catch (error) {
      sendIdentityError(res, error, 'Unable to verify Google sign-in.');
    }
    return;
  }

  if (req.method === 'POST' && pathname === '/api/v1/auth/withdrawal/otp/request') {
    const session = getUserSession(req);
    if (!session) {
      sendJson(res, 401, { error: 'Sign in is required before verifying a payout phone.' });
      return;
    }

    try {
      const { phone } = parseOtpRequest(await readBody(req));
      const result = await identity.requestWithdrawalPhoneOtp(session.sub, phone);
      sendJson(res, 200, { ok: true, ...result });
    } catch (error) {
      if (error instanceof OtpRateLimitError || (error instanceof Error && error.message === 'OTP_RATE_LIMITED')) {
        sendJson(res, 429, { error: 'Too many OTP requests. Please wait and try again.' });
      } else if (error instanceof OtpDeliveryError || error instanceof EmailDeliveryUnavailableError) {
        sendJson(res, 503, { error: 'Supabase phone verification is unavailable. Please try again later.' });
      } else if (error instanceof TypeError || error instanceof RangeError) {
        sendJson(res, 400, { error: error.message });
      } else {
        sendJson(res, 500, { error: 'Unable to request phone verification.' });
      }
    }
    return;
  }

  if (req.method === 'POST' && pathname === '/api/v1/auth/withdrawal/otp/verify') {
    const session = getUserSession(req);
    if (!session) {
      sendJson(res, 401, { error: 'Sign in is required before verifying a payout phone.' });
      return;
    }

    try {
      const { phone, code } = parseOtpVerificationRequest(await readBody(req));
      const result = await identity.verifyWithdrawalPhoneOtp(session.sub, phone, code);
      sendJson(res, 200, { ok: true, ...result });
    } catch (error) {
      if (error instanceof InvalidOtpError) {
        sendJson(res, 401, { error: 'OTP is invalid or expired.' });
      } else if (error instanceof InvalidVerificationError) {
        sendJson(res, 401, { error: error.message });
      } else if (error instanceof TypeError || error instanceof RangeError) {
        sendJson(res, 400, { error: error.message });
      } else {
        sendJson(res, 500, { error: 'Unable to verify payout phone.' });
      }
    }
    return;
  }

  if (req.method === 'POST' && pathname === '/api/v1/auth/otp/request') {
    try {
      const { phone } = parseOtpRequest(await readBody(req));
      const result = await service.requestOtp(phone, hashIpAddress(req.socket.remoteAddress));
      sendJson(res, 200, { ok: true, ...result });
    } catch (error) {
      if (error instanceof OtpRateLimitError || (error instanceof Error && error.message === 'OTP_RATE_LIMITED')) {
        sendJson(res, 429, { error: 'Too many OTP requests. Please wait and try again.' });
      } else if (error instanceof OtpDeliveryError) {
        sendJson(res, 503, { error: 'OTP delivery is unavailable. Please try again later.' });
      } else if (error instanceof TypeError || error instanceof RangeError) {
        sendJson(res, 400, { error: error.message });
      } else {
        sendJson(res, 500, { error: 'Unable to request OTP.' });
      }
      return;
    }
    return;
  }

  if (req.method === 'POST' && pathname === '/api/v1/auth/otp/verify') {
    try {
      const { phone, code } = parseOtpVerificationRequest(await readBody(req));
      const result = await service.verifyOtp(phone, code);
      sendJson(res, 200, { ok: true, ...result });
    } catch (error) {
      if (error instanceof InvalidOtpError) {
        sendJson(res, 401, { error: 'OTP is invalid or expired.' });
      } else if (error instanceof TypeError || error instanceof RangeError) {
        sendJson(res, 400, { error: error.message });
      } else {
        sendJson(res, 500, { error: 'Unable to verify OTP.' });
      }
      return;
    }
    return;
  }

  sendJson(res, 404, { ok: false, error: 'authentication route not found' });
}

export { otpService };