import test from 'node:test';
import assert from 'node:assert/strict';

import { handleHomeProfileRoute } from './homeProfile.js';

function createMockResponse() {
  return {
    statusCode: 0,
    headers: {},
    body: '',
    writeHead(statusCode, headers) {
      this.statusCode = statusCode;
      this.headers = headers;
    },
    end(body) {
      this.body = body;
    },
  };
}

async function requestRoute(pathname, session = null) {
  const req = {
    method: 'GET',
    headers: session ? { authorization: 'Bearer test-token' } : {},
  };
  const res = createMockResponse();

  await handleHomeProfileRoute(req, res, pathname, {
    verifyToken: () => session,
  });

  return { status: res.statusCode, body: JSON.parse(res.body) };
}

test('home route returns guest marketplace content and balances', async () => {
  const result = await requestRoute('/api/v1/home');

  assert.equal(result.status, 200);
  assert.equal(result.body.signedIn, false);
  assert.equal(result.body.balances.availableCoins, 0);
  assert.equal(Array.isArray(result.body.featured), true);
  assert.equal(result.body.featured.length > 0, true);
});

test('profile route reflects signed-in session claims without exposing secrets', async () => {
  const result = await requestRoute('/api/v1/profile', {
    sub: 'user-abc12345',
    email: 'user@example.com',
    email_verified: true,
    phone_verified: false,
  });

  assert.equal(result.status, 200);
  assert.equal(result.body.signedIn, true);
  assert.equal(result.body.user.id, 'user-abc12345');
  assert.equal(result.body.user.email, 'user@example.com');
  assert.equal(result.body.referral.code, 'PEARN-USER-ABC');
});
