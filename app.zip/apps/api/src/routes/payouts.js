import { createPayoutRequest, isPayoutAllowed, resolvePayoutStatus } from '../domain/payouts.js';
import { parseCashWithdrawalRequest } from '@rewards-platform/validation';
import { verifyAccessToken } from '../security/session.js';
import { config } from '../config.js';
import { pool } from '../db.js';

const payoutStore = new Map();
const idempotencyStore = new Map();

const seededPayouts = [
  {
    id: 'payout-1',
    userId: 'user-1',
    amount: 200,
    provider: 'razorpayx',
    payoutType: 'upi',
    status: 'pending',
  },
];

for (const payout of seededPayouts) {
  payoutStore.set(`${payout.userId}:${payout.id}`, createPayoutRequest(payout));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];

    req.on('data', (chunk) => {
      chunks.push(chunk);
    });

    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');

      if (!raw) {
        resolve({});
        return;
      }

      try {
        resolve(JSON.parse(raw));
      } catch (error) {
        reject(new Error('invalid JSON body'));
      }
    });

    req.on('error', reject);
  });
}

export function listPayoutsForUser(userId) {
  return [...payoutStore.values()]
    .filter((payout) => payout.userId === userId)
    .map((payout) => ({ ...payout, status: resolvePayoutStatus(payout.status) }));
}

async function hasMinimumKyc(userId) {
  const result = await pool.query(`
    SELECT EXISTS (
      SELECT 1
      FROM users u
      WHERE u.id = $1
        AND u.phone_verified_at IS NOT NULL
        AND u.minimum_kyc_verified_at IS NOT NULL
    ) AS verified
  `, [userId]);

  return result.rows[0]?.verified === true;
}

function authorizeUser(req, requestedUserId, verifyToken) {
  const authorization = req.headers.authorization ?? '';
  const tokenMatch = authorization.match(/^Bearer\s+(.+)$/i);
  const session = tokenMatch ? verifyToken(tokenMatch[1]) : null;

  if (!session) return { status: 401, error: 'Sign in is required.' };
  if (session.sub !== requestedUserId) return { status: 403, error: 'This account cannot access that resource.' };
  return { session };
}

function defaultPayoutDependencies() {
  return {
    verifyToken: (token) => verifyAccessToken(token, config.jwtSecret, { scope: 'user' }),
    hasMinimumKyc,
  };
}

export async function handlePayoutsRoute(req, res, userId, pathname, dependencies = defaultPayoutDependencies()) {
  const authorization = authorizeUser(req, userId, dependencies.verifyToken);
  if (!authorization.session) {
    res.writeHead(authorization.status, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: authorization.error }));
    return;
  }

  if (req.method === 'GET' && pathname === `/api/v1/payouts/${userId}`) {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ payouts: listPayoutsForUser(userId) }));
    return;
  }

  if (req.method === 'POST' && pathname === `/api/v1/payouts/${userId}`) {
    try {
      const payload = parseCashWithdrawalRequest(await readBody(req));
      const idempotencyKey = `${userId}:${payload.idempotencyKey}`;
      const existingPayoutId = idempotencyStore.get(idempotencyKey);

      if (existingPayoutId) {
        const existingPayout = payoutStore.get(`${userId}:${existingPayoutId}`);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ payout: existingPayout }));
        return;
      }

      if (!await dependencies.hasMinimumKyc(userId)) {
        res.writeHead(403, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          error: 'Phone OTP verification (Minimum KYC) is required before cash withdrawal.',
          code: 'MINIMUM_KYC_REQUIRED',
          nextAction: 'verify_phone',
        }));
        return;
      }

      const payout = createPayoutRequest({
        userId,
        amount: payload.amount,
        provider: 'razorpayx',
        payoutType: payload.payoutType,
        status: 'pending',
      });

      if (!isPayoutAllowed(payout)) {
        throw new Error('payout request is not allowed');
      }

      const payoutId = `payout-${Date.now()}`;
      const createdPayout = { ...payout, id: payoutId };
      payoutStore.set(`${userId}:${payoutId}`, createdPayout);
      idempotencyStore.set(idempotencyKey, payoutId);

      res.writeHead(201, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ payout: createdPayout }));
      return;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'unknown payout error';
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: message }));
      return;
    }
  }

  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ ok: false, error: 'payout route not found' }));
}
