import http from 'node:http';

import { handleOffersRoute } from './routes/offers.js';
import { handleAuthRoute, otpService } from './routes/auth.js';
import { handlePayoutsRoute } from './routes/payouts.js';
import { handleProductsRoute } from './routes/products.js';
import { handleRewardsRoute } from './routes/rewards.js';
import { handleWalletRoute } from './routes/wallet.js';

export function createApp({ authService = otpService, identityService, authConfig, payoutDependencies } = {}) {
  return http.createServer(async (req, res) => {
    const url = new URL(req.url ?? '/', 'http://localhost');

    if (url.pathname === '/') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        name: 'Rewards Platform API',
        status: 'running',
        version: '0.1.0',
      }));
      return;
    }

    if (url.pathname === '/api/health') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        ok: true,
        service: 'rewards-platform-api',
        env: process.env.NODE_ENV ?? 'development',
        timestamp: new Date().toISOString(),
      }));
      return;
    }

    if (url.pathname.startsWith('/api/v1/auth/')) {
      await handleAuthRoute(req, res, url.pathname, authService, identityService, authConfig);
      return;
    }

    if (url.pathname === '/api/v1/products' || url.pathname === '/api/v1/orders') {
      await handleProductsRoute(req, res, url.pathname);
      return;
    }

    if (url.pathname === '/api/v1/offers' || url.pathname.startsWith('/api/v1/offers')) {
      await handleOffersRoute(req, res, url.pathname);
      return;
    }

    const rewardsMatch = url.pathname.match(/^\/api\/v1\/rewards\/([^/]+)$/);

    if (rewardsMatch) {
      await handleRewardsRoute(req, res, rewardsMatch[1], url.pathname);
      return;
    }

    const payoutsMatch = url.pathname.match(/^\/api\/v1\/payouts\/([^/]+)$/);

    if (payoutsMatch) {
      await handlePayoutsRoute(req, res, decodeURIComponent(payoutsMatch[1]), url.pathname, payoutDependencies);
      return;
    }

    const walletMatch = url.pathname.match(/^\/api\/v1\/wallet\/([^/]+)(\/transactions)?$/);

    if (walletMatch) {
      await handleWalletRoute(req, res, walletMatch[1], url.pathname);
      return;
    }

    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: false, error: 'Not found' }));
  });
}
