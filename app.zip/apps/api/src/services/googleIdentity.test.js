import test from 'node:test';
import assert from 'node:assert/strict';
import { generateKeyPairSync, sign } from 'node:crypto';

import { verifyGoogleIdToken } from './googleIdentity.js';

const now = Date.parse('2026-10-06T12:00:00.000Z');
const { privateKey, publicKey } = generateKeyPairSync('rsa', { modulusLength: 2048 });
const jwk = { ...publicKey.export({ format: 'jwk' }), kid: 'test-google-key', alg: 'RS256', use: 'sig' };

function createToken(overrides = {}, signingKey = privateKey) {
  const header = Buffer.from(JSON.stringify({ alg: 'RS256', kid: 'test-google-key', typ: 'JWT' })).toString('base64url');
  const payload = Buffer.from(JSON.stringify({
    iss: 'https://accounts.google.com',
    aud: 'google-web-client-id',
    exp: Math.floor(now / 1000) + 600,
    sub: 'google-subject',
    email: 'verified@example.com',
    email_verified: true,
    name: 'Verified Person',
    nonce: 'server-issued-nonce',
    ...overrides,
  })).toString('base64url');
  const unsigned = `${header}.${payload}`;
  return `${unsigned}.${sign('RSA-SHA256', Buffer.from(unsigned), signingKey).toString('base64url')}`;
}

const fetchKeySet = async () => ({
  ok: true,
  headers: { get: () => 'public, max-age=300' },
  json: async () => ({ keys: [jwk] }),
});

test('Google ID token validates signature and identity claims', async () => {
  const profile = await verifyGoogleIdToken(createToken(), {
    clientId: 'google-web-client-id',
    fetchImpl: fetchKeySet,
    now: () => now,
  });

  assert.deepEqual(profile, {
    subject: 'google-subject',
    email: 'verified@example.com',
    fullName: 'Verified Person',
    nonce: 'server-issued-nonce',
  });
});

test('Google ID token rejects invalid audience, expiry, and signature', async () => {
  await assert.rejects(() => verifyGoogleIdToken(createToken({ aud: 'other-client-id' }), {
    clientId: 'google-web-client-id', fetchImpl: fetchKeySet, now: () => now,
  }));
  await assert.rejects(() => verifyGoogleIdToken(createToken({ exp: Math.floor(now / 1000) - 1 }), {
    clientId: 'google-web-client-id', fetchImpl: fetchKeySet, now: () => now,
  }));
  const otherKey = generateKeyPairSync('rsa', { modulusLength: 2048 }).privateKey;
  await assert.rejects(() => verifyGoogleIdToken(createToken({}, otherKey), {
    clientId: 'google-web-client-id', fetchImpl: fetchKeySet, now: () => now,
  }));
});
