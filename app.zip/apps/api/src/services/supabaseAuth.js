export class SupabaseAuthError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

export function createSupabaseAuthClient({ url, anonKey, serviceRoleKey, fetchImpl = fetch }) {
  const baseUrl = url?.replace(/\/$/, '');

  async function request(path, { body, method = 'POST', admin = false, accessToken, redirectTo } = {}) {
    const key = admin ? serviceRoleKey : anonKey;
    if (!baseUrl || !key) {
      throw new SupabaseAuthError(503, 'Supabase Auth is not configured');
    }

    let response;
    try {
      const redirectQuery = redirectTo ? `?redirect_to=${redirectTo}` : '';
      response = await fetchImpl(`${baseUrl}/auth/v1${path}${redirectQuery}`, {
        method,
        headers: {
          apikey: key,
          authorization: `Bearer ${accessToken ?? key}`,
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        ...(body === undefined ? {} : { body: JSON.stringify(body) }),
        signal: AbortSignal.timeout(10_000),
      });
    } catch {
      throw new SupabaseAuthError(503, 'Supabase Auth is unavailable');
    }

    let payload;
    try {
      payload = await response.json();
    } catch {
      payload = {};
    }
    if (!response.ok) {
      throw new SupabaseAuthError(response.status, 'Supabase Auth rejected the request');
    }
    return payload;
  }

  return {
    requestEmailOtp(email, metadata, emailRedirectTo) {
      const redirectTo = encodeURIComponent(emailRedirectTo);
      return request('/otp', {
        body: { email, create_user: true, data: metadata },
        redirectTo,
      });
    },

    async generateEmailSignupLink(email, metadata, emailRedirectTo) {
      return request('/admin/generate_link', {
        admin: true,
        body: { type: 'signup', email, data: metadata, redirect_to: emailRedirectTo },
      });
    },

    verifyEmailCode(email, code) {
      return request('/verify', { body: { email, token: code, type: 'email' } });
    },

    verifyEmailLink(tokenHash, type = 'signup') {
      return request('/verify', { body: { token_hash: tokenHash, type } });
    },

    getUser(accessToken) {
      return request('/user', { method: 'GET', accessToken });
    },

    exchangeGoogleIdToken(idToken, nonce) {
      return request('/token?grant_type=id_token', {
        body: { provider: 'google', id_token: idToken, nonce },
      });
    },

    async updateUserPhone(userId, phone) {
      return request(`/admin/users/${encodeURIComponent(userId)}`, {
        method: 'PUT',
        admin: true,
        body: { phone },
      });
    },

    requestPhoneOtp(phone) {
      return request('/otp', { body: { phone, create_user: true } });
    },

    verifyPhoneOtp(phone, code) {
      return request('/verify', { body: { phone, token: code, type: 'sms' } });
    },
  };
}