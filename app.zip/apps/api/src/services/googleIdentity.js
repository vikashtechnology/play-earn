import { createPublicKey, verify as verifySignature } from 'node:crypto';

const keySetUrl = 'https://www.googleapis.com/oauth2/v3/certs';
let cachedKeys;
let keysExpireAt = 0;

function decodeJson(value) {
  return JSON.parse(Buffer.from(value, 'base64url').toString('utf8'));
}

async function getGoogleKeySet(fetchImpl, now) {
  if (cachedKeys && keysExpireAt > now()) {
    return cachedKeys;
  }

  const response = await fetchImpl(keySetUrl, {
    headers: { Accept: 'application/json' },
    signal: AbortSignal.timeout(10_000),
  });
  if (!response.ok) {
    throw new Error('Google signing keys are unavailable');
  }

  const keySet = await response.json();
  if (!Array.isArray(keySet.keys)) {
    throw new Error('Google signing keys response is invalid');
  }

  const maxAge = Number(response.headers.get('cache-control')?.match(/max-age=(\d+)/)?.[1] ?? 300);
  cachedKeys = keySet.keys;
  keysExpireAt = now() + Math.max(60, Math.min(maxAge, 3600)) * 1000;
  return cachedKeys;
}

export async function verifyGoogleIdToken(token, {
  clientId,
  fetchImpl = fetch,
  now = Date.now,
} = {}) {
  if (!clientId) {
    throw new Error('Google sign-in is not configured');
  }

  const parts = token.split('.');
  if (parts.length !== 3 || token.length > 8192) {
    throw new Error('Google ID token is malformed');
  }

  const [encodedHeader, encodedPayload, encodedSignature] = parts;
  const header = decodeJson(encodedHeader);
  const claims = decodeJson(encodedPayload);
  if (header.alg !== 'RS256' || typeof header.kid !== 'string') {
    throw new Error('Google ID token algorithm is invalid');
  }

  const keys = await getGoogleKeySet(fetchImpl, now);
  const jwk = keys.find((key) => key.kid === header.kid && key.kty === 'RSA');
  if (!jwk) {
    throw new Error('Google signing key was not found');
  }

  const signingInput = Buffer.from(`${encodedHeader}.${encodedPayload}`);
  const signature = Buffer.from(encodedSignature, 'base64url');
  const publicKey = createPublicKey({ key: jwk, format: 'jwk' });
  if (!verifySignature('RSA-SHA256', signingInput, publicKey, signature)) {
    throw new Error('Google ID token signature is invalid');
  }

  const nowSeconds = Math.floor(now() / 1000);
  const issuerIsValid = claims.iss === 'https://accounts.google.com' || claims.iss === 'accounts.google.com';
  if (!issuerIsValid || claims.aud !== clientId || !Number.isInteger(claims.exp) || claims.exp <= nowSeconds) {
    throw new Error('Google ID token claims are invalid');
  }
  if (typeof claims.sub !== 'string' || !claims.sub || claims.email_verified !== true) {
    throw new Error('Google account must have a verified email');
  }
  if (typeof claims.email !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(claims.email)) {
    throw new Error('Google account email is invalid');
  }

  return {
    subject: claims.sub,
    email: claims.email.toLowerCase(),
    fullName: typeof claims.name === 'string' ? claims.name.slice(0, 255) : claims.email,
    nonce: typeof claims.nonce === 'string' ? claims.nonce : '',
  };
}
