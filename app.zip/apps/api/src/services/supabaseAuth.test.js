import test from 'node:test';
import assert from 'node:assert/strict';

import { createSupabaseAuthClient, SupabaseAuthError } from './supabaseAuth.js';

test('Supabase email OTP uses Auth API and signup redirect URL', async () => {
  let request;
  const client = createSupabaseAuthClient({
    url: 'https://project.supabase.co/',
    anonKey: 'public-test-key',
    serviceRoleKey: 'server-test-key',
    fetchImpl: async (url, options) => {
      request = { url, options };
      return { ok: true, json: async () => ({}) };
    },
  });

  await client.requestEmailOtp('person@example.com', { full_name: 'Person' }, 'playearnrealcash://auth/verify-email');

  assert.equal(request.url, 'https://project.supabase.co/auth/v1/otp?redirect_to=playearnrealcash%3A%2F%2Fauth%2Fverify-email');
  assert.equal(request.options.headers.apikey, 'public-test-key');
  assert.deepEqual(JSON.parse(request.options.body), {
    email: 'person@example.com',
    create_user: true,
    data: { full_name: 'Person' },
  });
});

test('Supabase fallback links use the server key and phone OTP uses Auth verification', async () => {
  const requests = [];
  const client = createSupabaseAuthClient({
    url: 'https://project.supabase.co',
    anonKey: 'public-test-key',
    serviceRoleKey: 'server-test-key',
    fetchImpl: async (url, options) => {
      requests.push({ url, options });
      return { ok: true, json: async () => ({ access_token: 'verified-session' }) };
    },
  });

  await client.generateEmailSignupLink('person@example.com', { full_name: 'Person' }, 'playearnrealcash://auth/verify-email');
  await client.requestPhoneOtp('+919876543210');
  await client.verifyPhoneOtp('+919876543210', '123456');

  assert.equal(requests[0].options.headers.apikey, 'server-test-key');
  assert.equal(requests[1].url, 'https://project.supabase.co/auth/v1/otp');
  assert.equal(requests[2].url, 'https://project.supabase.co/auth/v1/verify');
  assert.deepEqual(JSON.parse(requests[2].options.body), {
    phone: '+919876543210',
    token: '123456',
    type: 'sms',
  });
});

test('Supabase Auth errors never expose provider response details', async () => {
  const client = createSupabaseAuthClient({
    url: 'https://project.supabase.co',
    anonKey: 'public-test-key',
    serviceRoleKey: 'server-test-key',
    fetchImpl: async () => ({ ok: false, status: 429, json: async () => ({ msg: 'sensitive provider response' }) }),
  });

  await assert.rejects(
    () => client.requestEmailOtp('person@example.com', {}, 'playearnrealcash://auth/verify-email'),
    (error) => error instanceof SupabaseAuthError && !error.message.includes('sensitive'),
  );
});
