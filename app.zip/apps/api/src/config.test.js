import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import path from 'node:path';

const apiRoot = path.resolve(import.meta.dirname, '..');

test('runtime config reads Neon URLs, Supabase keys, and port from environment', () => {
  const result = spawnSync(process.execPath, [
    '--input-type=module',
    '-e',
    "import { config } from './src/config.js'; console.log(JSON.stringify({ port: config.port, postgresUrl: config.postgresUrl, migrationsPostgresUrl: config.migrationsPostgresUrl, supabaseUrl: config.supabaseUrl, supabaseAuthEnabled: config.supabaseAuthEnabled }));",
  ], {
    cwd: apiRoot,
    encoding: 'utf8',
    env: {
      ...process.env,
      PORT: '4317',
      POSTGRES_URL: 'postgresql://app:secret@pool.neon.tech/rewards?sslmode=require',
      MIGRATIONS_DATABASE_URL: 'postgresql://migrator:secret@direct.neon.tech/rewards?sslmode=require',
      SUPABASE_URL: 'https://test-project.supabase.co',
      SUPABASE_AUTH_ENABLED: 'true',
    },
  });

  assert.equal(result.status, 0, result.stderr);
  assert.deepEqual(JSON.parse(result.stdout.trim()), {
    port: 4317,
    postgresUrl: 'postgresql://app:secret@pool.neon.tech/rewards?sslmode=require',
    migrationsPostgresUrl: 'postgresql://migrator:secret@direct.neon.tech/rewards?sslmode=require',
    supabaseUrl: 'https://test-project.supabase.co',
    supabaseAuthEnabled: true,
  });
});
