import cors from 'cors';
import express from 'express';
import helmet from 'helmet';
import morgan from 'morgan';

import { env } from './config.js';
import { healthRouter } from './routes/health.js';

export const app = express();

app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(morgan(env.NODE_ENV === 'production' ? 'combined' : 'dev'));

app.get('/', (_req, res) => {
  res.json({
    name: 'Rewards Platform API',
    status: 'running',
    version: '0.1.0',
  });
});

app.use('/api', healthRouter);

app.use((err: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  const message = err instanceof Error ? err.message : 'Unknown error';

  res.status(500).json({
    ok: false,
    error: message,
  });
});
