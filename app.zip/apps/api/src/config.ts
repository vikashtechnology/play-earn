import dotenv from 'dotenv';
import { z } from 'zod';

dotenv.config();

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().default(4000),
  SUPABASE_DB_URL: z.string().optional(),
  SUPABASE_DB_DIRECT_URL: z.string().optional(),
  POSTGRES_URL: z.string().default('postgresql://postgres:postgres@localhost:5432/rewards_platform'),
  MIGRATIONS_DATABASE_URL: z.string().optional(),
  REDIS_URL: z.string().default('redis://localhost:6379'),
  JWT_SECRET: z.string().default('development-secret-change-me'),
});

export const env = envSchema.parse(process.env);
