import { timingSafeEqual } from 'node:crypto';

function safeEqual(bufferValue, candidateHex) {
  const stored = Buffer.from(bufferValue);
  const candidate = Buffer.from(candidateHex, 'hex');
  return stored.length === candidate.length && timingSafeEqual(stored, candidate);
}

export function createIdentityRepository(pool) {
  async function saveConsent(client, userId, challenge) {
    const consents = [
      ['terms', challenge.termsVersion, true],
      ['privacy_notice', challenge.privacyVersion, true],
      ['analytics', challenge.termsVersion, challenge.analyticsOptIn],
      ['personalized_offers', challenge.termsVersion, challenge.personalizedOffersOptIn],
    ];

    for (const [consentType, policyVersion, granted] of consents) {
      await client.query(`
        INSERT INTO user_consents (user_id, consent_type, policy_version, granted)
        SELECT $1, $2::VARCHAR(64), $3::VARCHAR(64), $4
        WHERE NOT EXISTS (
          SELECT 1 FROM user_consents
          WHERE user_id = $1
            AND consent_type = $2::VARCHAR(64)
            AND policy_version = $3::VARCHAR(64)
            AND granted = $4
        )
      `, [userId, consentType, policyVersion, granted]);
    }
  }

  async function provisionUser(client, { email, fullName, challenge, googleSubject = null, supabaseUserId = null }) {
    const result = await client.query(`
      INSERT INTO users (email, full_name, email_verified_at, google_subject, supabase_user_id, status)
      VALUES ($1, $2, NOW(), $3, $4, 'active')
      ON CONFLICT (email) DO UPDATE SET
        email_verified_at = COALESCE(users.email_verified_at, NOW()),
        google_subject = COALESCE(users.google_subject, EXCLUDED.google_subject),
        supabase_user_id = COALESCE(users.supabase_user_id, EXCLUDED.supabase_user_id),
        updated_at = NOW()
      WHERE (users.email_verified_at IS NULL OR users.google_subject = EXCLUDED.google_subject)
        AND (users.supabase_user_id IS NULL OR users.supabase_user_id = EXCLUDED.supabase_user_id)
      RETURNING id, email, full_name
    `, [email, fullName, googleSubject, supabaseUserId]);

    const user = result.rows[0];
    if (!user) {
      return null;
    }

    await client.query(`
      INSERT INTO wallets (user_id, balance, currency_code, status)
      VALUES ($1, 0, 'INR', 'active')
      ON CONFLICT (user_id) DO NOTHING
    `, [user.id]);
    if (challenge) {
      await saveConsent(client, user.id, challenge);
    }

    return user;
  }

  async function completeEmailChallenge({ email, candidateHash, verificationType, now, termsVersion, privacyVersion }) {
    const client = await pool.connect();

    try {
      await client.query('BEGIN');
      const selectedColumn = verificationType === 'link' ? 'link_token_hash' : 'code_hash';
      const result = await client.query(`
        SELECT id, full_name, terms_version, privacy_version,
               analytics_opt_in, personalized_offers_opt_in,
               ${selectedColumn} AS candidate_hash, expires_at, attempts
        FROM email_verification_challenges
        WHERE email = $1 AND consumed_at IS NULL
        ORDER BY created_at DESC
        LIMIT 1
        FOR UPDATE
      `, [email]);
      const challenge = result.rows[0];

      if (!challenge
        || new Date(challenge.expires_at) <= now
        || challenge.attempts >= 5
        || challenge.terms_version !== termsVersion
        || challenge.privacy_version !== privacyVersion) {
        if (challenge) {
          await client.query('UPDATE email_verification_challenges SET consumed_at = NOW() WHERE id = $1', [challenge.id]);
        }
        await client.query('COMMIT');
        return null;
      }

      const matches = safeEqual(challenge.candidate_hash, candidateHash);
      const attempts = challenge.attempts + 1;
      if (!matches) {
        await client.query(`
          UPDATE email_verification_challenges
          SET attempts = $2::SMALLINT,
              consumed_at = CASE WHEN $2::SMALLINT >= 5 THEN NOW() ELSE consumed_at END
          WHERE id = $1
        `, [challenge.id, attempts]);
        await client.query('COMMIT');
        return null;
      }

      await client.query('UPDATE email_verification_challenges SET consumed_at = NOW() WHERE id = $1', [challenge.id]);
      const user = await provisionUser(client, {
        email,
        fullName: challenge.full_name,
        challenge: {
          termsVersion: challenge.terms_version,
          privacyVersion: challenge.privacy_version,
          analyticsOptIn: challenge.analytics_opt_in,
          personalizedOffersOptIn: challenge.personalized_offers_opt_in,
        },
      });
      await client.query('COMMIT');
      return user;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  return {
    async markMinimumKycVerified(userId, phone, supabasePhoneUserId) {
      const result = await pool.query(`
        UPDATE users AS target
        SET phone = $2,
            supabase_phone_user_id = $3,
            phone_verified_at = COALESCE(target.phone_verified_at, NOW()),
            minimum_kyc_verified_at = NOW(),
            updated_at = NOW()
        WHERE target.id = $1
          AND NOT EXISTS (
            SELECT 1 FROM users AS other
            WHERE other.phone = $2 AND other.id <> target.id
          )
        RETURNING id
      `, [userId, phone, supabasePhoneUserId]);
      return result.rowCount === 1;
    },

    async findBySupabaseUserId(supabaseUserId) {
      const result = await pool.query(`
        SELECT id, email, full_name
        FROM users
        WHERE supabase_user_id = $1
      `, [supabaseUserId]);
      return result.rows[0] ?? null;
    },

    async completeSupabaseSignup({
      authUser,
      termsVersion,
      privacyVersion,
      allowDirectSignup = false,
      consent,
    }) {
      if (!authUser?.id || !authUser.email || !(authUser.email_confirmed_at || authUser.confirmed_at)) {
        return null;
      }

      const email = authUser.email.toLowerCase();
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [email]);
        const existing = await client.query(`
          SELECT id, email, full_name
          FROM users
          WHERE supabase_user_id = $1
          LIMIT 1
        `, [authUser.id]);
        if (existing.rows[0]) {
          if (consent) await saveConsent(client, existing.rows[0].id, consent);
          await client.query('COMMIT');
          return existing.rows[0];
        }

        const result = await client.query(`
          SELECT id, full_name, terms_version, privacy_version,
                 analytics_opt_in, personalized_offers_opt_in
          FROM email_verification_challenges
          WHERE email = $1 AND consumed_at IS NULL AND expires_at > NOW()
          ORDER BY created_at DESC
          LIMIT 1
          FOR UPDATE
        `, [email]);
        const pending = result.rows[0];

        if (pending && (pending.terms_version !== termsVersion || pending.privacy_version !== privacyVersion)) {
          await client.query('ROLLBACK');
          return null;
        }

        if (!pending && !allowDirectSignup) {
          await client.query('ROLLBACK');
          return null;
        }

        if (pending) {
          await client.query('UPDATE email_verification_challenges SET consumed_at = NOW() WHERE id = $1', [pending.id]);
        }
        const consentSnapshot = pending ? {
          termsVersion: pending.terms_version,
          privacyVersion: pending.privacy_version,
          analyticsOptIn: pending.analytics_opt_in,
          personalizedOffersOptIn: pending.personalized_offers_opt_in,
        } : consent;
        if (!consentSnapshot) {
          await client.query('ROLLBACK');
          return null;
        }
        const user = await provisionUser(client, {
          email,
          fullName: authUser.user_metadata?.full_name ?? pending?.full_name ?? email,
          supabaseUserId: authUser.id,
          challenge: consentSnapshot,
        });
        if (!user) {
          await client.query('ROLLBACK');
          return null;
        }
        await client.query('COMMIT');
        return user;
      } catch (error) {
        await client.query('ROLLBACK');
        throw error;
      } finally {
        client.release();
      }
    },

    async createEmailChallenge(challenge) {
      const client = await pool.connect();

      try {
        await client.query('BEGIN');
        await client.query("DELETE FROM email_verification_challenges WHERE created_at < NOW() - INTERVAL '1 day'");
        await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [challenge.email]);

        const recent = await client.query(`
          SELECT COUNT(*)::int AS count
          FROM email_verification_challenges
          WHERE email = $1 AND created_at > NOW() - INTERVAL '1 hour'
        `, [challenge.email]);
        if (recent.rows[0].count >= 5) {
          throw new Error('EMAIL_RATE_LIMITED');
        }

        if (challenge.requestIpHash) {
          const ipRecent = await client.query(`
            SELECT COUNT(*)::int AS count
            FROM email_verification_challenges
            WHERE request_ip_hash = $1 AND created_at > NOW() - INTERVAL '1 hour'
          `, [Buffer.from(challenge.requestIpHash, 'hex')]);
          if (ipRecent.rows[0].count >= 15) {
            throw new Error('EMAIL_RATE_LIMITED');
          }
        }

        await client.query(`
          UPDATE email_verification_challenges
          SET consumed_at = NOW()
          WHERE email = $1 AND consumed_at IS NULL
        `, [challenge.email]);

        await client.query(`
          INSERT INTO email_verification_challenges (
            id, email, full_name, code_hash, link_token_hash, terms_version,
            privacy_version, analytics_opt_in, personalized_offers_opt_in,
            request_ip_hash, expires_at
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
        `, [
          challenge.id,
          challenge.email,
          challenge.fullName,
          Buffer.from(challenge.codeHash, 'hex'),
          Buffer.from(challenge.linkTokenHash, 'hex'),
          challenge.termsVersion,
          challenge.privacyVersion,
          challenge.analyticsOptIn,
          challenge.personalizedOffersOptIn,
          challenge.requestIpHash ? Buffer.from(challenge.requestIpHash, 'hex') : null,
          challenge.expiresAt,
        ]);

        await client.query('COMMIT');
      } catch (error) {
        await client.query('ROLLBACK');
        if (error instanceof Error && error.message === 'EMAIL_RATE_LIMITED') throw error;
        throw error;
      } finally {
        client.release();
      }
    },

    async invalidateEmailChallenge(id) {
      await pool.query('UPDATE email_verification_challenges SET consumed_at = NOW() WHERE id = $1', [id]);
    },

    async verifyEmailCode(email, candidateHash, now, versions) {
      return completeEmailChallenge({ email, candidateHash, verificationType: 'code', now, ...versions });
    },

    async verifyEmailLink(email, candidateHash, now, versions) {
      return completeEmailChallenge({ email, candidateHash, verificationType: 'link', now, ...versions });
    },

    async createGoogleNonce(nonceHash, requestIpHash, expiresAt, consent = {}) {
      const client = await pool.connect();

      try {
        await client.query('BEGIN');
        await client.query("DELETE FROM google_login_nonces WHERE expires_at < NOW() - INTERVAL '1 day'");
        if (requestIpHash) {
          await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [requestIpHash]);
          const recent = await client.query(`
            SELECT COUNT(*)::int AS count
            FROM google_login_nonces
            WHERE request_ip_hash = $1 AND created_at > NOW() - INTERVAL '1 hour'
          `, [Buffer.from(requestIpHash, 'hex')]);
          if (recent.rows[0].count >= 20) {
            throw new Error('EMAIL_RATE_LIMITED');
          }
        }

        await client.query(`
          INSERT INTO google_login_nonces (
            nonce_hash, request_ip_hash, expires_at, terms_version, privacy_version,
            analytics_opt_in, personalized_offers_opt_in
          ) VALUES ($1, $2, $3, $4, $5, $6, $7)
        `, [
          Buffer.from(nonceHash, 'hex'),
          requestIpHash ? Buffer.from(requestIpHash, 'hex') : null,
          expiresAt,
          consent.termsVersion ?? null,
          consent.privacyVersion ?? null,
          consent.analyticsOptIn === true,
          consent.personalizedOffersOptIn === true,
        ]);
        await client.query('COMMIT');
      } catch (error) {
        await client.query('ROLLBACK');
        throw error;
      } finally {
        client.release();
      }
    },

    async consumeGoogleNonce(nonceHash, now) {
      const result = await pool.query(`
        UPDATE google_login_nonces
        SET consumed_at = NOW()
        WHERE nonce_hash = $1 AND consumed_at IS NULL AND expires_at > $2
        RETURNING nonce_hash, terms_version, privacy_version, analytics_opt_in, personalized_offers_opt_in
      `, [Buffer.from(nonceHash, 'hex'), now]);
      return result.rows[0] ?? null;
    },

    async markMinimumKycVerified(userId, phone, supabasePhoneUserId) {
      const result = await pool.query(`
        UPDATE users AS target
        SET phone = $2,
            supabase_phone_user_id = $3,
            phone_verified_at = COALESCE(target.phone_verified_at, NOW()),
            minimum_kyc_verified_at = NOW(),
            updated_at = NOW()
        WHERE target.id = $1
          AND NOT EXISTS (
            SELECT 1 FROM users AS other
            WHERE other.phone = $2 AND other.id <> target.id
          )
          AND NOT EXISTS (
            SELECT 1 FROM users AS other
            WHERE other.supabase_phone_user_id = $3 AND other.id <> target.id
          )
        RETURNING id
      `, [userId, phone, supabasePhoneUserId]);
      return result.rowCount === 1;
    },

    async createGoogleUser(profile, challenge) {
      const client = await pool.connect();

      try {
        await client.query('BEGIN');
        await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [profile.email]);

        const existing = await client.query(`
          SELECT id, email, full_name
          FROM users
          WHERE google_subject = $1
          LIMIT 1
        `, [profile.subject]);

        if (existing.rows[0]) {
          await saveConsent(client, existing.rows[0].id, challenge);
          await client.query('COMMIT');
          return existing.rows[0];
        }

        const user = await provisionUser(client, {
          email: profile.email,
          fullName: profile.fullName,
          googleSubject: profile.subject,
          challenge,
        });
        if (!user) {
          await client.query('ROLLBACK');
          return null;
        }

        await client.query('COMMIT');
        return user;
      } catch (error) {
        await client.query('ROLLBACK');
        throw error;
      } finally {
        client.release();
      }
    },
  };
}