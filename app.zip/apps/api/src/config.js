import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import { fileURLToPath } from 'node:url';

const currentDir = path.dirname(fileURLToPath(import.meta.url));
const envFile = path.resolve(currentDir, '../.env');

if (fs.existsSync(envFile)) {
  process.loadEnvFile(envFile);
}

const env = process.env;

export const config = {
  env: env.NODE_ENV ?? 'development',
  port: Number(env.PORT ?? 4000),
  postgresUrl: env.POSTGRES_URL ?? 'postgresql://postgres:postgres@localhost:5432/rewards_platform',
  migrationsPostgresUrl: env.MIGRATIONS_DATABASE_URL ?? env.POSTGRES_URL ?? 'postgresql://postgres:postgres@localhost:5432/rewards_platform',
  redisUrl: env.REDIS_URL ?? 'redis://localhost:6379',
  jwtSecret: env.JWT_SECRET ?? 'development-secret-change-me',
  authProvider: env.AUTH_PROVIDER ?? 'supabase',
  supabaseAuthEnabled: env.SUPABASE_AUTH_ENABLED === 'true',
  supabaseUrl: env.SUPABASE_URL ?? '',
  supabaseAnonKey: env.SUPABASE_ANON_KEY ?? '',
  supabaseServiceRoleKey: env.SUPABASE_SERVICE_ROLE_KEY ?? '',
  otpHashSecret: env.OTP_HASH_SECRET ?? env.JWT_SECRET ?? 'development-otp-hash-secret-change-me',
  otpDeliveryEnabled: env.OTP_DELIVERY_ENABLED === 'true',
  otpProvider: env.OTP_PROVIDER ?? 'fast2sms',
  otpProviderApiKey: env.OTP_PROVIDER_API_KEY ?? '',
  signupEnabled: env.SIGNUP_ENABLED === 'true',
  emailProvider: env.EMAIL_PROVIDER ?? 'resend',
  emailProviderApiKey: env.EMAIL_PROVIDER_API_KEY ?? '',
  emailFallbackApiKey: env.EMAIL_FALLBACK_API_KEY ?? '',
  emailFrom: env.EMAIL_FROM ?? '',
  emailVerificationLinkBase: env.EMAIL_VERIFICATION_LINK_BASE ?? 'playearnrealcash://auth/verify-email',
  googleSignInEnabled: env.GOOGLE_SIGNIN_ENABLED === 'true',
  googleWebClientId: env.GOOGLE_WEB_CLIENT_ID ?? '',
  termsVersion: env.TERMS_VERSION ?? '',
  privacyVersion: env.PRIVACY_VERSION ?? '',
  termsUrl: env.TERMS_URL ?? '',
  privacyUrl: env.PRIVACY_URL ?? '',
};
