import test from 'node:test';
import assert from 'node:assert/strict';

import {
  createIdentityService,
  EmailDeliveryUnavailableError,
  InvalidVerificationError,
} from './identity.js';
import { verifyAccessToken } from '../security/session.js';

function createRepository() {
  const challenges = new Map();
  const nonces = new Set();
  const users = new Map();

  return {
    challenges,
    users,
    async createEmailChallenge(challenge) {
      challenges.set(challenge.id, { ...challenge, consumed: false });
    },
    async invalidateEmailChallenge(id) {
      const challenge = challenges.get(id);
      if (challenge) challenge.consumed = true;
    },
    async verifyEmailCode(email, candidateHash, _now, versions) {
      return consumeEmailChallenge(email, candidateHash, 'codeHash', versions);
    },
    async verifyEmailLink(email, candidateHash, _now, versions) {
      return consumeEmailChallenge(email, candidateHash, 'linkTokenHash', versions);
    },
    async createGoogleNonce(nonceHash) {
      nonces.add(nonceHash);
    },
    async consumeGoogleNonce(nonceHash) {
      if (!nonces.has(nonceHash)) return false;
      nonces.delete(nonceHash);
      return true;
    },
    async createGoogleUser(profile) {
      const user = { id: 'google-user-id', email: profile.email, full_name: profile.fullName };
      users.set(user.id, user);
      return user;
    },
  };

  async function consumeEmailChallenge(email, candidateHash, hashField, versions) {
    const challenge = [...challenges.values()].find((item) => item.email === email && !item.consumed);
    if (!challenge
      || challenge[hashField] !== candidateHash
      || challenge.expiresAt <= new Date()
      || challenge.termsVersion !== versions.termsVersion
      || challenge.privacyVersion !== versions.privacyVersion) return null;
    challenge.consumed = true;
    const user = { id: 'email-user-id', email, full_name: challenge.fullName };
    users.set(user.id, { user, challenge });
    return user;
  }
}

function setup(overrides = {}) {
  const repository = createRepository();
  const sentLinks = [];
  const deliveredOtps = [];

  // ponytail: minimal supabaseAuth stub — only the methods identity.js calls
  const supabaseAuth = {
    async requestEmailOtp(email, metadata) {
      deliveredOtps.push({ email, metadata });
    },
    async generateEmailSignupLink(email, metadata, redirectTo) {
      const token = 'stub-link-token-' + email;
      sentLinks.push({ email, verificationUrl: `playearnrealcash://auth/verify-email?email=${email}&token=${token}` });
      return { action_link: sentLinks.at(-1).verificationUrl };
    },
    async verifyEmailCode(email, code) {
      // find the challenge by matching the code stored in sentCodes
      const challenge = [...repository.challenges.values()].find((c) => c.email === email && !c.consumed);
      if (!challenge) throw new Error('invalid or expired');
      return { user: { id: 'supa-' + email, email, email_confirmed_at: new Date().toISOString(), user_metadata: { full_name: challenge.fullName } } };
    },
    async getUser(token) {
      const email = token.replace('stub-token-', '');
      return { id: 'supa-' + email, email, email_confirmed_at: new Date().toISOString() };
    },
    async exchangeGoogleIdToken(credential, nonce) {
      const profile = JSON.parse(credential);
      if (profile.nonce !== nonce) throw new Error('nonce mismatch');
      return { user: { id: 'supa-google-' + profile.subject, email: profile.email, email_confirmed_at: new Date().toISOString(), user_metadata: { full_name: profile.fullName } } };
    },
    async requestPhoneOtp(phone) { return {}; },
    async verifyPhoneOtp(phone, code) {
      return { user: { id: 'supa-phone-' + phone, phone, phone_confirmed_at: new Date().toISOString() } };
    },
    ...overrides.supabaseAuth,
  };

  const service = createIdentityService({
    repository,
    supabaseAuth,
    sendFallbackLink: async (message) => sentLinks.push(message),
    challengeSecret: 'test-challenge-secret',
    jwtSecret: 'test-session-secret',
    verificationBaseUrl: 'playearnrealcash://auth/verify-email',
    termsVersion: 'terms-v1',
    privacyVersion: 'privacy-v1',
    ...overrides,
  });

  return { service, repository, sentLinks, deliveredOtps };
}

const signupInput = {
  email: 'person@example.com',
  fullName: 'Example Person',
  analyticsOptIn: false,
  personalizedOffersOptIn: true,
};

test('email signup sends OTP via Supabase and provisions a session after verification', async () => {
  const context = setup();
  const requested = await context.service.requestEmailSignup(signupInput, null);

  assert.equal(requested.deliveryMethod, 'code');
  assert.equal(context.deliveredOtps.length, 1);
  assert.equal(context.deliveredOtps[0].email, signupInput.email);
  assert.equal(requested.emailHint, 'p***@example.com');

  // verifyEmailCode calls supabaseAuth.verifyEmailCode → completeSupabaseSignup
  const session = await context.service.verifyEmailCode(signupInput.email, '123456');
  const token = verifyAccessToken(session.accessToken, 'test-session-secret', { scope: 'user' });

  assert.equal(token.email_verified, true);
  assert.equal(token.phone_verified, false);
  assert.equal(session.user.email, signupInput.email);
});

test('email signup falls back to a one-time link if code delivery fails', async () => {
  const context = setup({
    sendVerificationCode: async () => { throw new Error('primary mail provider unavailable'); },
  });
  const requested = await context.service.requestEmailSignup(signupInput, null);
  const token = new URL(context.sentLinks[0].verificationUrl).searchParams.get('token');
  const email = new URL(context.sentLinks[0].verificationUrl).searchParams.get('email');

  assert.equal(requested.deliveryMethod, 'link');
  assert.equal(context.sentLinks.length, 1);
  assert.equal(token.length >= 40, true);
  const session = await context.service.verifyEmailLink(email, token);
  assert.equal(session.user.email, signupInput.email);
  await assert.rejects(() => context.service.verifyEmailLink(email, token), InvalidVerificationError);
});

test('signup fails closed if both verification delivery methods fail', async () => {
  const context = setup({
    sendVerificationCode: async () => { throw new Error('primary failed'); },
    sendFallbackLink: async () => { throw new Error('fallback failed'); },
  });

  await assert.rejects(() => context.service.requestEmailSignup(signupInput, null), EmailDeliveryUnavailableError);
  assert.equal([...context.repository.challenges.values()][0].consumed, true);
});

test('email verification cannot accept consent captured under stale policy versions', async () => {
  const context = setup();
  await context.service.requestEmailSignup(signupInput, null);
  const code = context.sentCodes[0].code;
  const changedPolicyService = createIdentityService({
    repository: context.repository,
    sendVerificationCode: async () => {},
    sendFallbackLink: async () => {},
    challengeSecret: 'test-challenge-secret',
    jwtSecret: 'test-session-secret',
    verificationBaseUrl: 'playearnrealcash://auth/verify-email',
    termsVersion: 'terms-v2',
    privacyVersion: 'privacy-v2',
  });

  await assert.rejects(() => changedPolicyService.verifyEmailCode(signupInput.email, code), InvalidVerificationError);
});

test('Google signup requires a fresh one-time nonce and creates a phone-unverified user', async () => {
  const context = setup();
  const { nonce } = await context.service.createGoogleNonce(null);
  const credential = JSON.stringify({
    subject: 'google-subject-123',
    email: signupInput.email,
    fullName: signupInput.fullName,
    nonce,
  });
  const consent = {
    analyticsOptIn: false,
    personalizedOffersOptIn: false,
  };
  const session = await context.service.signInWithGoogle(credential, nonce, consent, null);

  assert.equal(session.user.emailVerified, true);
  assert.equal(session.user.phoneVerified, false);
  await assert.rejects(() => context.service.signInWithGoogle(credential, nonce, consent, null), InvalidVerificationError);
});
