import { createHmac, randomBytes, randomUUID } from 'node:crypto';

import { issueAccessToken } from '../security/session.js';

export class IdentityRateLimitError extends Error {}
export class EmailDeliveryUnavailableError extends Error {}
export class InvalidVerificationError extends Error {}

const emailChallengeLifetimeSeconds = 600;
const googleNonceLifetimeSeconds = 300;

function hashValue(value, secret) {
  return createHmac('sha256', secret).update(value).digest('hex');
}

function userSession(user, { jwtSecret, now, supabaseSession = {} }) {
  return {
    accessToken: issueAccessToken({
      subject: user.id,
      scope: 'user',
      secret: jwtSecret,
      now,
      claims: {
        email: user.email,
        email_verified: true,
        phone_verified: false,
      },
    }),
    tokenType: 'Bearer',
    expiresInSeconds: 900,
    supabaseAccessToken: supabaseSession.access_token ?? null,
    supabaseRefreshToken: supabaseSession.refresh_token ?? null,
    user: {
      id: user.id,
      email: user.email,
      fullName: user.full_name,
      emailVerified: true,
      phoneVerified: false,
    },
  };
}

export function createIdentityService({
  repository,
  supabaseAuth,
  sendFallbackLink,
  challengeSecret,
  jwtSecret,
  verificationBaseUrl,
  termsVersion,
  privacyVersion,
  now = Date.now,
}) {
  if (!repository || !challengeSecret || !jwtSecret) {
    throw new TypeError('Identity service requires a repository and signing secrets');
  }

  return {
    async requestEmailSignup(input, requestIpHash) {
      const challenge = {
        id: randomUUID(),
        email: input.email,
        fullName: input.fullName,
        codeHash: hashValue(randomBytes(32), challengeSecret),
        linkTokenHash: hashValue(randomBytes(32), challengeSecret),
        requestIpHash,
        termsVersion,
        privacyVersion,
        analyticsOptIn: input.analyticsOptIn,
        personalizedOffersOptIn: input.personalizedOffersOptIn,
        expiresAt: new Date(now() + emailChallengeLifetimeSeconds * 1000),
      };

      try {
        await repository.createEmailChallenge(challenge);
      } catch (error) {
        if (error instanceof Error && error.message === 'EMAIL_RATE_LIMITED') {
          throw new IdentityRateLimitError('Please wait before requesting another verification email');
        }
        throw error;
      }

      let deliveryMethod = 'code';

      try {
        if (!supabaseAuth) throw new EmailDeliveryUnavailableError('Supabase Auth is not configured');
        await supabaseAuth.requestEmailOtp(input.email, {
          full_name: input.fullName,
          terms_version: termsVersion,
          privacy_version: privacyVersion,
          analytics_opt_in: input.analyticsOptIn,
          personalized_offers_opt_in: input.personalizedOffersOptIn,
        }, verificationBaseUrl);
      } catch {
        deliveryMethod = 'link';
        try {
          if (!supabaseAuth || !sendFallbackLink) throw new EmailDeliveryUnavailableError('Email fallback is not configured');
          const link = await supabaseAuth.generateEmailSignupLink(input.email, {
            full_name: input.fullName,
            terms_version: termsVersion,
            privacy_version: privacyVersion,
            analytics_opt_in: input.analyticsOptIn,
            personalized_offers_opt_in: input.personalizedOffersOptIn,
          }, verificationBaseUrl);
          const verificationUrl = link.action_link ?? link.properties?.action_link;
          if (!verificationUrl) throw new EmailDeliveryUnavailableError('Supabase did not return a signup link');
          await sendFallbackLink({ email: input.email, fullName: input.fullName, verificationUrl });
        } catch {
          await repository.invalidateEmailChallenge(challenge.id);
          throw new EmailDeliveryUnavailableError('Email verification is unavailable. Try again later.');
        }
      }

      return {
        deliveryMethod,
        expiresInSeconds: emailChallengeLifetimeSeconds,
        emailHint: input.email.replace(/^(.).+(@.+)$/, '$1***$2'),
      };
    },

    async verifyEmailCode(email, code) {
      let authSession;
      try {
        authSession = await supabaseAuth.verifyEmailCode(email, code);
      } catch {
        throw new InvalidVerificationError('Email code is invalid or expired');
      }
      const user = await repository.completeSupabaseSignup({
        authUser: authSession.user,
        termsVersion,
        privacyVersion,
      });
      if (!user) throw new InvalidVerificationError('Email code is invalid or expired');
      return userSession(user, { jwtSecret, now, supabaseSession: authSession });
    },

    async verifyEmailLink(supabaseAccessToken) {
      let authUser;
      try {
        authUser = await supabaseAuth.getUser(supabaseAccessToken);
      } catch {
        throw new InvalidVerificationError('Email link is invalid or expired');
      }
      const user = await repository.completeSupabaseSignup({
        authUser,
        termsVersion,
        privacyVersion,
      });
      if (!user) throw new InvalidVerificationError('Email link is invalid or expired');
      return userSession(user, { jwtSecret, now, supabaseSession: { access_token: supabaseAccessToken } });
    },

    async createGoogleNonce(requestIpHash, consent) {
      const nonce = randomBytes(32).toString('base64url');
      try {
        await repository.createGoogleNonce(
          hashValue(nonce, challengeSecret),
          requestIpHash,
          new Date(now() + googleNonceLifetimeSeconds * 1000),
          {
            termsVersion,
            privacyVersion,
            analyticsOptIn: consent.analyticsOptIn,
            personalizedOffersOptIn: consent.personalizedOffersOptIn,
          },
        );
      } catch (error) {
        if (error instanceof Error && error.message === 'EMAIL_RATE_LIMITED') {
          throw new IdentityRateLimitError('Google sign-in rate limit reached');
        }
        throw error;
      }
      return { nonce, expiresInSeconds: googleNonceLifetimeSeconds };
    },

    async signInWithGoogle(credential, expectedNonce) {
      let authSession;
      try {
        authSession = await supabaseAuth.exchangeGoogleIdToken(credential, expectedNonce);
      } catch {
        throw new InvalidVerificationError('Google sign-in could not be verified');
      }

      const nonceConsent = await repository.consumeGoogleNonce(hashValue(expectedNonce, challengeSecret), new Date(now()));
      if (!nonceConsent) throw new InvalidVerificationError('Google sign-in request expired or was already used');

      const user = await repository.completeSupabaseSignup({
        authUser: authSession.user,
        termsVersion,
        privacyVersion,
        allowDirectSignup: true,
        consent: {
          termsVersion: nonceConsent.terms_version,
          privacyVersion: nonceConsent.privacy_version,
          analyticsOptIn: nonceConsent.analytics_opt_in,
          personalizedOffersOptIn: nonceConsent.personalized_offers_opt_in,
        },
      });
      if (!user) throw new InvalidVerificationError('This email is already registered to another sign-in method');

      return userSession(user, { jwtSecret, now, supabaseSession: authSession });
    },

    async requestWithdrawalPhoneOtp(userId, phone) {
      try {
        await supabaseAuth.requestPhoneOtp(phone);
      } catch {
        throw new EmailDeliveryUnavailableError('Supabase phone verification is unavailable');
      }
      return { expiresInSeconds: 300, resendInSeconds: 60 };
    },

    async verifyWithdrawalPhoneOtp(userId, phone, code) {
      let authSession;
      try {
        authSession = await supabaseAuth.verifyPhoneOtp(phone, code);
      } catch {
        throw new InvalidVerificationError('Phone code is invalid or expired');
      }

      const authUser = authSession.user;
      if (!authUser?.id || authUser.phone !== phone || !(authUser.phone_confirmed_at || authUser.confirmed_at)) {
        throw new InvalidVerificationError('Supabase did not confirm this phone number');
      }

      const updated = await repository.markMinimumKycVerified(userId, phone, authUser.id);
      if (!updated) throw new InvalidVerificationError('Phone number is already linked to another account');
      return { minimumKycVerified: true };
    },
  };
}