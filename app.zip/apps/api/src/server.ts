import { env } from './config.js';
import { app } from './app.js';

const port = env.PORT;

app.listen(port, () => {
  console.log(`Rewards Platform API listening on http://localhost:${port}`);
});
