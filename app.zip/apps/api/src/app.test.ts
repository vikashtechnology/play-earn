import { describe, expect, it } from 'vitest';
import request from 'supertest';

import { app } from './app.js';

describe('API bootstrap', () => {
  it('returns service details on root route', async () => {
    const response = await request(app).get('/');

    expect(response.status).toBe(200);
    expect(response.body).toMatchObject({
      name: 'Rewards Platform API',
      status: 'running',
    });
  });

  it('returns health status for the service', async () => {
    const response = await request(app).get('/api/health');

    expect(response.status).toBe(200);
    expect(response.body).toMatchObject({
      ok: true,
      service: 'rewards-platform-api',
    });
  });
});
