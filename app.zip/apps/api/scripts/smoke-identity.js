import { createHmac, randomBytes, randomInt, randomUUID } from 'node:crypto';
import { pool } from '../src/db.js';
import { createIdentityRepository } from '../src/db/identityRepository.js';
import { createOtpRepository } from '../src/db/otpRepository.js';

const identity = createIdentityRepository(pool);
const otp = createOtpRepository(pool);
const id = randomUUID();
const email = `smoke-${id}@example.invalid`;
const secret = randomBytes(32);
const hash = (value) => createHmac('sha256', secret).update(value).digest('hex');
const nonceHash = hash(randomBytes(32));
let userId;

try {
  await identity.createEmailChallenge({
    id,
    email,
    fullName: 'Synthetic Smoke User',
    codeHash: hash(`${email}:123456`),
    linkTokenHash: hash(randomBytes(32)),
    requestIpHash: null,
    termsVersion: 'smoke-terms',
    privacyVersion: 'smoke-privacy',
    analyticsOptIn: false,
    personalizedOffersOptIn: false,
    expiresAt: new Date(Date.now() + 600000),
  });
  const user = await identity.verifyEmailCode(email, hash(`${email}:123456`), new Date(), {
    termsVersion: 'smoke-terms',
    privacyVersion: 'smoke-privacy',
  });
  if (!user) throw new Error('Email signup smoke failed');
  userId = user.id;

  await identity.createGoogleNonce(nonceHash, null, new Date(Date.now() + 300000));
  if (!await identity.consumeGoogleNonce(nonceHash, new Date())) throw new Error('Google nonce consume failed');
  if (await identity.consumeGoogleNonce(nonceHash, new Date())) throw new Error('Google nonce replay succeeded');

  const phone = `+91${6}${randomInt(100000000, 1000000000)}`;
  const phoneHash = hash(`phone:${phone}`);
  const codeHash = hash(`${phone}:654321`);
  await otp.createChallenge({
    id: randomUUID(), phoneHash, codeHash, requestIpHash: null, userId,
    purpose: 'withdrawal', expiresAt: new Date(Date.now() + 300000),
  });
  if (!await otp.verifyChallenge(phoneHash, codeHash, new Date(), { userId, purpose: 'withdrawal', phone })) {
    throw new Error('Minimum-KYC phone verification failed');
  }

  const status = await pool.query('SELECT phone_verified_at, minimum_kyc_verified_at FROM users WHERE id = $1', [userId]);
  if (!status.rows[0]?.phone_verified_at || !status.rows[0]?.minimum_kyc_verified_at) {
    throw new Error('Minimum-KYC timestamps were not persisted');
  }
  console.log('IDENTITY_NEON_SMOKE_OK');
} finally {
  if (userId) await pool.query('DELETE FROM users WHERE id = $1', [userId]);
  await pool.query('DELETE FROM email_verification_challenges WHERE email = $1', [email]);
  await pool.query('DELETE FROM google_login_nonces WHERE nonce_hash = $1', [Buffer.from(nonceHash, 'hex')]);
  await pool.end();
}
