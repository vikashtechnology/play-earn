# Android app

Kotlin + Jetpack Compose Android application scaffold for **Play & Earn Real Cash**, an India-first rewards marketplace.

## Open and build

- Open this directory in Android Studio.
- Use JDK 17, Android SDK 36, and Gradle 8.11.1 or newer compatible with Android Gradle Plugin 8.9.1.
- Allow Android Studio to resolve the Gradle plugins and Compose dependencies.
- Build the `app` run configuration on an emulator or device.
- The debug build targets the API on the Android emulator host at `http://10.0.2.2:4000`; override with `-PAPI_BASE_URL=https://your-api-host` for a device or deployed environment.
- Configure `-PGOOGLE_WEB_CLIENT_ID=...` with the OAuth web client ID registered for the backend audience before enabling Google sign-in.
- The API remains fail-closed until reviewed Terms/Privacy URLs and versions, transactional email credentials, Fast2SMS/DLT setup, and Google OAuth configuration are provided.

The app includes a guest marketplace shell, email/Google signup UI, and a separate OTP phone-verification flow for cash payout Minimum KYC. Signup and email delivery remain disabled until the backend has approved policy URLs/versions and provider credentials. Use `ui/theme/RewardsTokens.kt` as the Android mapping of the canonical values in the repository's `design.md`.

No provider credentials belong in the Android app. Configure secret values only on the backend.
