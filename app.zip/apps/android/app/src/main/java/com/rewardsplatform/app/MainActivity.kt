package com.rewardsplatform.app

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.rewardsplatform.app.auth.OtpSignInScreen
import com.rewardsplatform.app.auth.CashWithdrawalScreen
import com.rewardsplatform.app.auth.SessionTokenStore
import com.rewardsplatform.app.auth.SignupScreen
import com.rewardsplatform.app.ui.theme.RewardsMarketplaceTheme
import com.rewardsplatform.app.ui.theme.RewardsTokens

private enum class MarketplaceTab(val title: String) {
    Home("Home"),
    Earn("Earn"),
    Rewards("Rewards"),
    Wallet("Wallet"),
    Profile("Profile"),
}

class MainActivity : ComponentActivity() {
    private val incomingVerificationLink = mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        incomingVerificationLink.value = intent?.data
        enableEdgeToEdge()
        setContent {
            RewardsMarketplaceTheme {
                MarketplaceApp(
                    incomingVerificationLink = incomingVerificationLink.value,
                    onVerificationLinkHandled = { incomingVerificationLink.value = null },
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        incomingVerificationLink.value = intent.data
    }
}

@Composable
private fun MarketplaceApp(
    incomingVerificationLink: Uri?,
    onVerificationLinkHandled: () -> Unit,
) {
    val context = LocalContext.current
    val tokenStore = remember(context) { SessionTokenStore(context) }
    var selectedTabName by rememberSaveable { mutableStateOf(MarketplaceTab.Home.name) }
    var ageConfirmed by rememberSaveable { mutableStateOf(false) }
    var showSignIn by rememberSaveable { mutableStateOf(false) }
    var showWithdrawalPhoneVerification by rememberSaveable { mutableStateOf(false) }
    var showCashWithdrawal by rememberSaveable { mutableStateOf(false) }
    var phoneVerified by rememberSaveable { mutableStateOf(tokenStore.isMinimumKycVerified()) }
    var showConsentPreferences by rememberSaveable { mutableStateOf(false) }
    var analyticsOptIn by rememberSaveable { mutableStateOf(false) }
    var partnerPersonalizationOptIn by rememberSaveable { mutableStateOf(false) }
    var showPolicyNotice by rememberSaveable { mutableStateOf(false) }
    val selectedTab = MarketplaceTab.valueOf(selectedTabName)

    if (!ageConfirmed && incomingVerificationLink == null) {
        AgeGateScreen(onContinueAsGuest = { ageConfirmed = true })
        return
    }

    if (showSignIn || incomingVerificationLink != null) {
        SignupScreen(
            incomingVerificationLink = incomingVerificationLink,
            onVerificationLinkHandled = onVerificationLinkHandled,
            onBack = { showSignIn = false },
            onVerified = {
                showSignIn = false
                ageConfirmed = true
            },
        )
        return
    }

    if (showWithdrawalPhoneVerification) {
        val accessToken = tokenStore.readAccessToken()
        if (accessToken == null) {
            showSignIn = true
            return
        }
        OtpSignInScreen(
            withdrawalAccessToken = accessToken,
            onBack = { showWithdrawalPhoneVerification = false },
            onVerified = {
                phoneVerified = true
                showWithdrawalPhoneVerification = false
                showCashWithdrawal = true
            },
        )
        return
    }

    if (showCashWithdrawal) {
        val accessToken = tokenStore.readAccessToken()
        val userId = tokenStore.readUserId()
        if (accessToken == null || userId.isNullOrBlank()) {
            showCashWithdrawal = false
            showSignIn = true
            return
        }
        CashWithdrawalScreen(
            accessToken = accessToken,
            userId = userId,
            onClose = { showCashWithdrawal = false },
        )
        return
    }

    if (showConsentPreferences) {
        ConsentPreferencesScreen(
            analyticsOptIn = analyticsOptIn,
            onAnalyticsOptInChange = { analyticsOptIn = it },
            partnerPersonalizationOptIn = partnerPersonalizationOptIn,
            onPartnerPersonalizationChange = { partnerPersonalizationOptIn = it },
            onPolicyClick = { showPolicyNotice = true },
            onBack = { showConsentPreferences = false },
        )
        if (showPolicyNotice) {
            AlertDialog(
                onDismissRequest = { showPolicyNotice = false },
                title = { Text("Policies not published") },
                text = { Text("Privacy and Terms links will be available before account creation. Guest browsing does not create an account or save consent choices.") },
                confirmButton = {
                    TextButton(onClick = { showPolicyNotice = false }) { Text("Close") }
                },
            )
        }
        return
    }

    Surface(modifier = Modifier.fillMaxSize(), color = RewardsTokens.background) {
        androidx.compose.material3.Scaffold(
            modifier = Modifier.systemBarsPadding(),
            containerColor = RewardsTokens.background,
            bottomBar = {
                NavigationBar(containerColor = RewardsTokens.surface) {
                    MarketplaceTab.entries.forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTabName = tab.name },
                            icon = {},
                            label = { Text(tab.title) },
                        )
                    }
                }
            },
        ) { contentPadding ->
            when (selectedTab) {
                MarketplaceTab.Home -> HomeScreen(Modifier.padding(contentPadding))
                MarketplaceTab.Earn -> EarnScreen(Modifier.padding(contentPadding))
                MarketplaceTab.Rewards -> RewardsScreen(
                    modifier = Modifier.padding(contentPadding),
                    phoneVerified = phoneVerified,
                    onCashPayoutClick = {
                        val accessToken = tokenStore.readAccessToken()
                        if (accessToken == null || tokenStore.readUserId().isNullOrBlank()) {
                            showWithdrawalPhoneVerification = true
                            showSignIn = true
                        } else if (tokenStore.isMinimumKycVerified()) {
                            showCashWithdrawal = true
                        } else {
                            showWithdrawalPhoneVerification = true
                        }
                    },
                )
                MarketplaceTab.Wallet -> WalletScreen(Modifier.padding(contentPadding))
                MarketplaceTab.Profile -> ProfileScreen(
                    modifier = Modifier.padding(contentPadding),
                    onConsentClick = { showConsentPreferences = true },
                    onSignInClick = { showSignIn = true },
                    phoneVerified = phoneVerified,
                )
            }
        }
    }

}

@Composable
private fun AgeGateScreen(onContinueAsGuest: () -> Unit) {
    var isAdult by rememberSaveable { mutableStateOf(false) }
    var showMinorNotice by rememberSaveable { mutableStateOf(false) }

    ScreenColumn {
        ScreenTitle(
            eyebrow = "Play & Earn Real Cash",
            title = "A rewards marketplace, built around verified activity.",
            supporting = "Browse as a guest. Cash payout availability depends on eligibility and verification; earnings are not guaranteed.",
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(RewardsTokens.spacingSmall),
        ) {
            Checkbox(checked = isAdult, onCheckedChange = { isAdult = it })
            Text(
                text = "I confirm that I am 18 years of age or older.",
                modifier = Modifier.weight(1f).padding(top = RewardsTokens.spacingMedium),
                style = MaterialTheme.typography.bodyLarge,
                color = RewardsTokens.text,
            )
        }
        Button(
            onClick = onContinueAsGuest,
            enabled = isAdult,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("Explore as guest")
        }
        TextButton(onClick = {
            isAdult = false
            showMinorNotice = true
        }) {
            Text("I am under 18")
        }
        Text(
            text = "Guest browsing does not create an account or collect personal details. Account setup remains unavailable until approved policy links and verified consent recording are ready.",
            style = MaterialTheme.typography.bodySmall,
            color = RewardsTokens.muted,
        )
    }

    if (showMinorNotice) {
        AlertDialog(
            onDismissRequest = { showMinorNotice = false },
            title = { Text("Account setup unavailable") },
            text = { Text("Verified parental consent is not available yet, so users under 18 cannot continue.") },
            confirmButton = {
                TextButton(onClick = { showMinorNotice = false }) { Text("Close") }
            },
        )
    }
}

@Composable
private fun ScreenColumn(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = RewardsTokens.spacingLarge, vertical = RewardsTokens.spacingLarge),
        verticalArrangement = Arrangement.spacedBy(RewardsTokens.spacingLarge),
        content = content,
    )
}

@Composable
private fun ScreenTitle(eyebrow: String, title: String, supporting: String? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(RewardsTokens.spacingSmall)) {
        Text(
            text = eyebrow.uppercase(),
            style = MaterialTheme.typography.labelLarge,
            color = RewardsTokens.accent,
        )
        Text(
            text = title,
            style = MaterialTheme.typography.headlineMedium,
            color = RewardsTokens.text,
        )
        if (supporting != null) {
            Text(
                text = supporting,
                style = MaterialTheme.typography.bodyMedium,
                color = RewardsTokens.muted,
            )
        }
    }
}

@Composable
private fun BalancePanel(title: String, note: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(RewardsTokens.cardRadius),
        colors = CardDefaults.cardColors(containerColor = RewardsTokens.surface),
        border = BorderStroke(1.dp, RewardsTokens.border),
    ) {
        Column(
            modifier = Modifier.padding(RewardsTokens.spacingLarge),
            verticalArrangement = Arrangement.spacedBy(RewardsTokens.spacingSmall),
        ) {
            Text(title.uppercase(), style = MaterialTheme.typography.labelMedium, color = RewardsTokens.muted)
            Text("--", style = MaterialTheme.typography.headlineMedium, color = RewardsTokens.primary)
            Text(note, style = MaterialTheme.typography.bodyMedium, color = RewardsTokens.muted)
        }
    }
}

@Composable
private fun LinkRow(title: String, supporting: String, onClick: () -> Unit = {}) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = RewardsTokens.spacingSmall),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = RewardsTokens.text)
        Text(supporting, style = MaterialTheme.typography.bodyMedium, color = RewardsTokens.muted)
    }
}

@Composable
private fun HomeScreen(modifier: Modifier = Modifier) {
    ScreenColumn(modifier) {
        ScreenTitle(
            eyebrow = "Play & Earn Real Cash",
            title = "Rewards beyond the offerwall.",
            supporting = "Discover verified offers, surveys, check-ins, and brand rewards. Cash payout availability depends on eligibility and verification.",
        )
        BalancePanel("Your rewards balance", "Sign in to view available and pending coins.")
        Column(verticalArrangement = Arrangement.spacedBy(RewardsTokens.spacingMedium)) {
            Text("Explore the marketplace", style = MaterialTheme.typography.titleLarge, color = RewardsTokens.text)
            LinkRow("Surveys and activities", "Browse partner tasks with clear reward conditions.")
            LinkRow("Brand rewards", "Discover promotions and product offers from brands.")
            LinkRow("Products and vouchers", "Explore rewards available in the catalog.")
        }
    }
}

@Composable
private fun EarnScreen(modifier: Modifier = Modifier) {
    ScreenColumn(modifier) {
        ScreenTitle("Earn", "Choose how to take part", "Reward amounts and availability vary by campaign and eligibility.")
        LinkRow("Surveys", "Share feedback through participating research partners.")
        LinkRow("Daily check-in", "Check in when this activity is available.")
        LinkRow("Brand activities", "Explore sponsored tasks and promotions.")
        LinkRow("Partner offers", "Review the terms and verification steps before starting.")
        LinkRow("App offers", "Install offers open only through a Google Play Store listing.")
        BalancePanel("Watch video for in-app coins", "Ad rewards are for in-app use only and cannot be redeemed for cash or gift cards.")
    }
}

@Composable
private fun RewardsScreen(
    modifier: Modifier = Modifier,
    phoneVerified: Boolean,
    onCashPayoutClick: () -> Unit,
) {
    ScreenColumn(modifier) {
        ScreenTitle("Rewards", "Browse the catalog", "Catalog items and redemption terms depend on availability.")
        LinkRow("Gift cards and vouchers", "Redeem eligible rewards through an approved provider.")
        LinkRow("Products", "Some products may support a coin and cash co-pay.")
        LinkRow(
            "Cash payout",
            if (phoneVerified) "Phone verified. Additional eligibility and payout setup may apply."
            else "Verify your phone with OTP (Minimum KYC) before requesting a cash payout.",
            onCashPayoutClick,
        )
    }
}

@Composable
private fun WalletScreen(modifier: Modifier = Modifier) {
    ScreenColumn(modifier) {
        ScreenTitle("Wallet", "Your coin activity", "Coins are rewards, not money held in an INR wallet.")
        BalancePanel("Available", "Sign in to see coins cleared for eligible redemption.")
        BalancePanel("Pending", "Partner activity is verified before coins become available.")
        BalancePanel("Reserved", "Coins in a checkout or redemption are shown separately.")
        BalancePanel("In-app ad coins", "AdMob coins are restricted to in-app use.")
        Text("Transaction history appears after sign-in.", style = MaterialTheme.typography.bodyMedium, color = RewardsTokens.muted)
    }
}

@Composable
private fun ProfileScreen(
    modifier: Modifier = Modifier,
    onConsentClick: () -> Unit,
    onSignInClick: () -> Unit,
    phoneVerified: Boolean,
) {
    ScreenColumn(modifier) {
        ScreenTitle("Profile", "Your account", "Sign in to manage your profile and preferences.")
        if (phoneVerified) {
            LinkRow("Phone verified", "Profile and account setup will follow after consent and account services are ready.")
        } else {
            LinkRow("Sign in", "Verify your Indian mobile number with a one-time code.", onSignInClick)
        }
        LinkRow("Support", "Get help with offers, payouts, rewards, or orders.")
        LinkRow("Privacy and consent", "Review separate optional preference controls.", onConsentClick)
        LinkRow("Account deletion", "Account deletion will be available in the account flow.")
    }
}

@Composable
private fun ConsentPreferencesScreen(
    analyticsOptIn: Boolean,
    onAnalyticsOptInChange: (Boolean) -> Unit,
    partnerPersonalizationOptIn: Boolean,
    onPartnerPersonalizationChange: (Boolean) -> Unit,
    onPolicyClick: () -> Unit,
    onBack: () -> Unit,
) {
    ScreenColumn {
        TextButton(onClick = onBack) { Text("Back") }
        ScreenTitle("Privacy choices", "Optional preferences", "Each optional purpose has its own control and starts off disabled.")
        PreferenceSwitch(
            title = "Product analytics",
            supporting = "Allow pseudonymous usage measurement to help improve the app.",
            checked = analyticsOptIn,
            onCheckedChange = onAnalyticsOptInChange,
        )
        PreferenceSwitch(
            title = "Personalized partner offers",
            supporting = "Allow activity preferences to be used to tailor partner offer recommendations.",
            checked = partnerPersonalizationOptIn,
            onCheckedChange = onPartnerPersonalizationChange,
        )
        Text(
            text = "These controls are a preview only: choices are held for this session and are not sent or saved. Account creation is unavailable until the approved Privacy Notice, Terms, and server-side consent records are implemented.",
            style = MaterialTheme.typography.bodyMedium,
            color = RewardsTokens.muted,
        )
        TextButton(onClick = onPolicyClick) { Text("Privacy notice and Terms status") }
        Text(
            text = "Notifications will be requested only when a notification feature is enabled, not during guest onboarding.",
            style = MaterialTheme.typography.bodySmall,
            color = RewardsTokens.muted,
        )
    }
}

@Composable
private fun PreferenceSwitch(
    title: String,
    supporting: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(RewardsTokens.spacingMedium),
    ) {
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = RewardsTokens.text)
            Text(supporting, style = MaterialTheme.typography.bodySmall, color = RewardsTokens.muted)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}