package com.rewardsplatform.app.auth

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class SessionTokenStore(context: Context) {
    private val preferences = context.getSharedPreferences("auth_session", Context.MODE_PRIVATE)

    fun saveAccessToken(token: String, expiresInSeconds: Int, userId: String = "", phoneVerified: Boolean = false) {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.iv + cipher.doFinal(token.toByteArray(Charsets.UTF_8))
        preferences.edit()
            .putString(TOKEN_KEY, Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .putLong(EXPIRY_KEY, System.currentTimeMillis() + expiresInSeconds * 1_000L)
            .putString(USER_ID_KEY, userId)
            .putBoolean(PHONE_VERIFIED_KEY, phoneVerified)
            .putBoolean(MINIMUM_KYC_KEY, false)
            .apply()
    }

    fun readAccessToken(): String? {
        if (preferences.getLong(EXPIRY_KEY, 0L) <= System.currentTimeMillis()) {
            clear()
            return null
        }
        val stored = preferences.getString(TOKEN_KEY, null) ?: return null
        val encrypted = Base64.decode(stored, Base64.NO_WRAP)
        if (encrypted.size <= IV_LENGTH) return null

        val iv = encrypted.copyOfRange(0, IV_LENGTH)
        val ciphertext = encrypted.copyOfRange(IV_LENGTH, encrypted.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(TAG_LENGTH_BITS, iv))
        return cipher.doFinal(ciphertext).toString(Charsets.UTF_8)
    }

    fun clear() {
        preferences.edit()
            .remove(TOKEN_KEY)
            .remove(EXPIRY_KEY)
            .remove(USER_ID_KEY)
            .remove(PHONE_VERIFIED_KEY)
            .remove(MINIMUM_KYC_KEY)
            .apply()
    }

    fun markMinimumKycVerified() {
        preferences.edit()
            .putBoolean(PHONE_VERIFIED_KEY, true)
            .putBoolean(MINIMUM_KYC_KEY, true)
            .apply()
    }

    fun readUserId(): String? = preferences.getString(USER_ID_KEY, null)

    fun isMinimumKycVerified(): Boolean {
        return readAccessToken() != null && preferences.getBoolean(MINIMUM_KYC_KEY, false)
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEY_STORE).apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEY_STORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build(),
        )
        return generator.generateKey()
    }

    private companion object {
        const val ANDROID_KEY_STORE = "AndroidKeyStore"
        const val KEY_ALIAS = "play_earn_session_key"
        const val TOKEN_KEY = "access_token"
        const val EXPIRY_KEY = "access_token_expires_at"
        const val USER_ID_KEY = "user_id"
        const val PHONE_VERIFIED_KEY = "phone_verified"
        const val MINIMUM_KYC_KEY = "minimum_kyc_verified"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val IV_LENGTH = 12
        const val TAG_LENGTH_BITS = 128
    }
}
