package com.rewardsplatform.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class BalanceSummary(
    val availableCoins: Int,
    val pendingCoins: Int,
    val reservedCoins: Int,
    val reversedCoins: Int,
    val adMobInAppCoins: Int,
)

data class FeaturedItem(
    val title: String,
    val supporting: String,
    val rewardCoins: Int,
)

data class HomeOverview(
    val signedIn: Boolean,
    val balances: BalanceSummary,
    val featured: List<FeaturedItem>,
)

data class ProfileOverview(
    val signedIn: Boolean,
    val email: String?,
    val referralCode: String?,
    val supportEmail: String,
)

class MarketplaceApi(private val baseUrl: String = BuildConfig.API_BASE_URL) {
    suspend fun loadHome(accessToken: String?): HomeOverview = withContext(Dispatchers.IO) {
        val response = get("/api/v1/home", accessToken)
        val balances = response.getJSONObject("balances")
        HomeOverview(
            signedIn = response.optBoolean("signedIn"),
            balances = BalanceSummary(
                availableCoins = balances.optInt("availableCoins"),
                pendingCoins = balances.optInt("pendingCoins"),
                reservedCoins = balances.optInt("reservedCoins"),
                reversedCoins = balances.optInt("reversedCoins"),
                adMobInAppCoins = balances.optInt("adMobInAppCoins"),
            ),
            featured = response.optJSONArray("featured").toFeaturedItems(),
        )
    }

    suspend fun loadProfile(accessToken: String?): ProfileOverview = withContext(Dispatchers.IO) {
        val response = get("/api/v1/profile", accessToken)
        val user = response.optJSONObject("user")
        val referral = response.optJSONObject("referral")
        val support = response.optJSONObject("support") ?: JSONObject()
        ProfileOverview(
            signedIn = response.optBoolean("signedIn"),
            email = user?.optString("email")?.takeUnless { it.isBlank() || it == "null" },
            referralCode = referral?.optString("code")?.takeUnless { it.isBlank() || it == "null" },
            supportEmail = support.optString("email", "support@example.com"),
        )
    }

    private fun get(path: String, accessToken: String?): JSONObject {
        val connection = URL(baseUrl.trimEnd('/') + path).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 10_000
        connection.readTimeout = 10_000
        connection.setRequestProperty("Accept", "application/json")
        accessToken?.let { connection.setRequestProperty("Authorization", "Bearer $it") }

        try {
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val response = if (body.isBlank()) JSONObject() else JSONObject(body)

            if (status !in 200..299) {
                throw IllegalStateException(response.optString("error", "Request failed."))
            }

            return response
        } finally {
            connection.disconnect()
        }
    }
}

private fun JSONArray?.toFeaturedItems(): List<FeaturedItem> {
    if (this == null) return emptyList()
    return (0 until length()).mapNotNull { index ->
        optJSONObject(index)?.let { item ->
            FeaturedItem(
                title = item.optString("title"),
                supporting = item.optString("description"),
                rewardCoins = item.optInt("rewardCoins"),
            )
        }
    }
}
