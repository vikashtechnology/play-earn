package com.rewardsplatform.app.auth

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.rewardsplatform.app.ui.theme.RewardsTokens
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun OtpSignInScreen(
    onBack: () -> Unit,
    onVerified: () -> Unit,
    withdrawalAccessToken: String? = null,
) {
    var phoneDigits by remember { mutableStateOf("") }
    var otp by remember { mutableStateOf("") }
    var codeRequested by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var resendInSeconds by remember { mutableIntStateOf(0) }
    var expiresInSeconds by remember { mutableIntStateOf(0) }
    val api = remember { AuthApi() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val requestCode: () -> Unit = {
        scope.launch {
            isLoading = true
            errorMessage = null
            try {
                val result = if (withdrawalAccessToken == null) {
                    api.requestOtp("+91$phoneDigits")
                } else {
                    api.requestWithdrawalPhoneOtp("+91$phoneDigits", withdrawalAccessToken)
                }
                codeRequested = true
                otp = ""
                resendInSeconds = result.resendInSeconds
                expiresInSeconds = result.expiresInSeconds
            } catch (error: AuthApiException) {
                errorMessage = error.message
            } catch (_: Exception) {
                errorMessage = "Could not connect. Check your connection and try again."
            } finally {
                isLoading = false
            }
        }
    }

    LaunchedEffect(resendInSeconds, expiresInSeconds) {
        if (resendInSeconds > 0 || expiresInSeconds > 0) {
            delay(1_000)
            if (resendInSeconds > 0) resendInSeconds -= 1
            if (expiresInSeconds > 0) expiresInSeconds -= 1
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = RewardsTokens.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            TextButton(onClick = onBack) { Text("Back") }
            Text("PHONE VERIFICATION", style = MaterialTheme.typography.labelLarge, color = RewardsTokens.accent)
            Text(
                text = if (codeRequested) "Enter your code" else "Sign in with your phone",
                style = MaterialTheme.typography.headlineMedium,
                color = RewardsTokens.text,
            )
            Text(
                text = "We use a one-time code to verify your number. Never share it with anyone.",
                style = MaterialTheme.typography.bodyMedium,
                color = RewardsTokens.muted,
            )

            if (!codeRequested) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = "+91",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Country") },
                        modifier = Modifier.weight(0.3f),
                    )
                    OutlinedTextField(
                        value = phoneDigits,
                        onValueChange = { value -> phoneDigits = value.filter(Char::isDigit).take(10) },
                        label = { Text("Mobile number") },
                        supportingText = { Text("India mobile number") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.weight(0.7f),
                    )
                }
                Button(
                    onClick = requestCode,
                    enabled = phoneDigits.length == 10 && !isLoading,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    if (isLoading) CircularProgressIndicator()
                    else Text("Send code")
                }
            } else {
                Text("Code sent to +91 $phoneDigits", style = MaterialTheme.typography.bodyMedium, color = RewardsTokens.muted)
                OutlinedTextField(
                    value = otp,
                    onValueChange = { value -> otp = value.filter(Char::isDigit).take(6) },
                    label = { Text("6-digit code") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Button(
                    onClick = {
                        scope.launch {
                            isLoading = true
                            errorMessage = null
                            try {
                                if (withdrawalAccessToken == null) {
                                    val result = api.verifyOtp("+91$phoneDigits", otp)
                                    SessionTokenStore(context).saveAccessToken(result.accessToken, result.expiresInSeconds)
                                } else {
                                    val verified = api.verifyWithdrawalPhoneOtp(
                                        "+91$phoneDigits",
                                        otp,
                                        withdrawalAccessToken,
                                    )
                                    if (!verified) throw IllegalStateException("Phone verification was not confirmed")
                                    SessionTokenStore(context).markMinimumKycVerified()
                                }
                                onVerified()
                            } catch (error: AuthApiException) {
                                errorMessage = error.message
                            } catch (_: Exception) {
                                errorMessage = "Could not verify the code. Please try again."
                            } finally {
                                isLoading = false
                            }
                        }
                    },
                    enabled = otp.length == 6 && !isLoading && expiresInSeconds > 0,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    if (isLoading) CircularProgressIndicator()
                    else Text("Verify number")
                }
                TextButton(
                    onClick = requestCode,
                    enabled = resendInSeconds == 0 && !isLoading,
                ) {
                    Text(if (resendInSeconds > 0) "Resend in ${resendInSeconds}s" else "Resend code")
                }
                TextButton(
                    onClick = {
                        codeRequested = false
                        otp = ""
                        resendInSeconds = 0
                        expiresInSeconds = 0
                    },
                    enabled = !isLoading,
                ) {
                    Text("Change number")
                }
                Text("Code expires in ${expiresInSeconds}s", style = MaterialTheme.typography.bodySmall, color = RewardsTokens.muted)
            }

            if (errorMessage != null) {
                Text(errorMessage.orEmpty(), style = MaterialTheme.typography.bodyMedium, color = RewardsTokens.danger)
            }

            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}
