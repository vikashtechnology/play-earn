package com.rewardsplatform.app.auth

import com.rewardsplatform.app.BuildConfig
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class AuthApiException(val statusCode: Int, message: String) : Exception(message)

data class OtpRequestResult(
    val expiresInSeconds: Int,
    val resendInSeconds: Int,
)

data class OtpVerificationResult(
    val accessToken: String,
    val expiresInSeconds: Int,
)

data class AuthPolicies(
    val emailSignupEnabled: Boolean,
    val googleSignInEnabled: Boolean,
    val termsUrl: String?,
    val privacyUrl: String?,
)

data class EmailVerificationRequestResult(
    val deliveryMethod: String,
    val expiresInSeconds: Int,
    val emailHint: String,
)

data class UserSession(
    val accessToken: String,
    val expiresInSeconds: Int,
    val userId: String,
)

data class CashWithdrawalResult(
    val id: String,
    val status: String,
    val amount: Int,
    val payoutType: String,
)

data class GoogleNonce(
    val nonce: String,
    val expiresInSeconds: Int,
)

class AuthApi(private val baseUrl: String = BuildConfig.API_BASE_URL) {
    suspend fun loadAuthPolicies(): AuthPolicies = withContext(Dispatchers.IO) {
        val response = get("/api/v1/auth/policies")
        AuthPolicies(
            emailSignupEnabled = response.optBoolean("emailSignupEnabled"),
            googleSignInEnabled = response.optBoolean("googleSignInEnabled"),
            termsUrl = response.optString("termsUrl").takeUnless { it == "" || it == "null" },
            privacyUrl = response.optString("privacyUrl").takeUnless { it == "" || it == "null" },
        )
    }

    suspend fun requestEmailVerification(
        email: String,
        fullName: String,
        adultConfirmed: Boolean,
        termsAccepted: Boolean,
        privacyAccepted: Boolean,
        analyticsOptIn: Boolean,
        personalizedOffersOptIn: Boolean,
    ): EmailVerificationRequestResult = withContext(Dispatchers.IO) {
        val response = post(
            "/api/v1/auth/email/signup",
            JSONObject()
                .put("email", email)
                .put("fullName", fullName)
                .put("adultConfirmed", adultConfirmed)
                .put("termsAccepted", termsAccepted)
                .put("privacyAccepted", privacyAccepted)
                .put("analyticsOptIn", analyticsOptIn)
                .put("personalizedOffersOptIn", personalizedOffersOptIn),
        )
        EmailVerificationRequestResult(
            deliveryMethod = response.getString("deliveryMethod"),
            expiresInSeconds = response.getInt("expiresInSeconds"),
            emailHint = response.getString("emailHint"),
        )
    }

    suspend fun verifyEmailCode(email: String, code: String): UserSession = withContext(Dispatchers.IO) {
        parseUserSession(post("/api/v1/auth/email/verify", JSONObject().put("email", email).put("code", code)))
    }

    suspend fun verifyEmailLink(email: String, token: String): UserSession = withContext(Dispatchers.IO) {
        parseUserSession(post(
            "/api/v1/auth/email/verify-link",
            JSONObject().put("email", email).put("token", token),
        ))
    }

    suspend fun requestGoogleNonce(): GoogleNonce = withContext(Dispatchers.IO) {
        val response = post("/api/v1/auth/google/nonce", JSONObject())
        GoogleNonce(response.getString("nonce"), response.getInt("expiresInSeconds"))
    }

    suspend fun verifyGoogleCredential(credential: String, nonce: String): UserSession = withContext(Dispatchers.IO) {
        parseUserSession(post(
            "/api/v1/auth/google/verify",
            JSONObject()
                .put("credential", credential)
                .put("nonce", nonce)
                .put("adultConfirmed", true)
                .put("termsAccepted", true)
                .put("privacyAccepted", true)
                .put("analyticsOptIn", false)
                .put("personalizedOffersOptIn", false),
        ))
    }

    suspend fun requestWithdrawalPhoneOtp(phone: String, accessToken: String): OtpRequestResult = withContext(Dispatchers.IO) {
        val response = post("/api/v1/auth/withdrawal/otp/request", JSONObject().put("phone", phone), accessToken)
        OtpRequestResult(response.getInt("expiresInSeconds"), response.getInt("resendInSeconds"))
    }

    suspend fun verifyWithdrawalPhoneOtp(phone: String, code: String, accessToken: String): Boolean = withContext(Dispatchers.IO) {
        post(
            "/api/v1/auth/withdrawal/otp/verify",
            JSONObject().put("phone", phone).put("code", code),
            accessToken,
        ).optBoolean("minimumKycVerified")
    }

    suspend fun requestCashWithdrawal(
        userId: String,
        amount: Int,
        payoutType: String,
        idempotencyKey: String,
        accessToken: String,
    ): CashWithdrawalResult = withContext(Dispatchers.IO) {
        val response = post(
            "/api/v1/payouts/${Uri.encode(userId)}",
            JSONObject()
                .put("amount", amount)
                .put("payoutType", payoutType)
                .put("idempotencyKey", idempotencyKey),
            accessToken,
        ).getJSONObject("payout")
        CashWithdrawalResult(
            id = response.getString("id"),
            status = response.getString("status"),
            amount = response.getInt("amount"),
            payoutType = response.getString("payoutType"),
        )
    }

    suspend fun requestOtp(phone: String): OtpRequestResult = withContext(Dispatchers.IO) {
        val response = post("/api/v1/auth/otp/request", JSONObject().put("phone", phone))
        OtpRequestResult(
            expiresInSeconds = response.getInt("expiresInSeconds"),
            resendInSeconds = response.getInt("resendInSeconds"),
        )
    }

    suspend fun verifyOtp(phone: String, code: String): OtpVerificationResult = withContext(Dispatchers.IO) {
        val response = post(
            "/api/v1/auth/otp/verify",
            JSONObject().put("phone", phone).put("code", code),
        )
        OtpVerificationResult(
            accessToken = response.getString("accessToken"),
            expiresInSeconds = response.getInt("expiresInSeconds"),
        )
    }

    private fun parseUserSession(response: JSONObject) = UserSession(
        accessToken = response.getString("accessToken"),
        expiresInSeconds = response.getInt("expiresInSeconds"),
        userId = response.getJSONObject("user").getString("id"),
    )

    private fun get(path: String): JSONObject {
        val connection = URL(baseUrl.trimEnd('/') + path).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 10_000
        connection.readTimeout = 10_000
        connection.setRequestProperty("Accept", "application/json")
        return readResponse(connection)
    }

    private fun post(path: String, payload: JSONObject, accessToken: String? = null): JSONObject {
        val connection = URL(baseUrl.trimEnd('/') + path).openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.connectTimeout = 10_000
        connection.readTimeout = 10_000
        connection.doOutput = true
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        accessToken?.let { connection.setRequestProperty("Authorization", "Bearer $it") }

        try {
            connection.outputStream.use { output ->
                output.write(payload.toString().toByteArray(Charsets.UTF_8))
            }

            return readResponse(connection)
        } finally {
            connection.disconnect()
        }
    }

    private fun readResponse(connection: HttpURLConnection): JSONObject {
        try {
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val response = if (body.isBlank()) JSONObject() else JSONObject(body)

            if (status !in 200..299) {
                throw AuthApiException(status, response.optString("error", "Request failed. Please try again."))
            }

            return response
        } finally {
            connection.disconnect()
        }
    }
}
