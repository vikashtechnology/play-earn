package com.rewardsplatform.app.auth

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.rewardsplatform.app.BuildConfig
import com.rewardsplatform.app.ui.theme.RewardsTokens
import kotlinx.coroutines.launch

@Composable
fun SignupScreen(
    incomingVerificationLink: Uri?,
    onVerificationLinkHandled: () -> Unit,
    onBack: () -> Unit,
    onVerified: (UserSession) -> Unit,
) {
    var authPolicies by remember { mutableStateOf<AuthPolicies?>(null) }
    var loadingPolicies by remember { mutableStateOf(true) }
    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var codeRequested by remember { mutableStateOf(false) }
    var linkFallback by remember { mutableStateOf(false) }
    var adultConfirmed by remember { mutableStateOf(false) }
    var termsAccepted by remember { mutableStateOf(false) }
    var privacyAccepted by remember { mutableStateOf(false) }
    var analyticsOptIn by remember { mutableStateOf(false) }
    var personalizedOffersOptIn by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val api = remember { AuthApi() }
    val tokenStore = remember(context) { SessionTokenStore(context) }
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        try {
            authPolicies = api.loadAuthPolicies()
        } catch (_: Exception) {
            errorMessage = "Signup options could not be loaded. Check your connection and try again."
        } finally {
            loadingPolicies = false
        }
    }

    LaunchedEffect(incomingVerificationLink) {
        val link = incomingVerificationLink ?: return@LaunchedEffect
        if (link.scheme != "playearnrealcash" || link.host != "auth" || link.path != "/verify-email") {
            onVerificationLinkHandled()
            return@LaunchedEffect
        }

        val linkEmail = link.getQueryParameter("email")
        val linkToken = link.getQueryParameter("token")
        if (linkEmail.isNullOrBlank() || linkToken.isNullOrBlank()) {
            errorMessage = "This verification link is incomplete. Request a new email."
            onVerificationLinkHandled()
            return@LaunchedEffect
        }

        loading = true
        errorMessage = null
        try {
            val session = api.verifyEmailLink(linkEmail, linkToken)
            tokenStore.saveAccessToken(session.accessToken, session.expiresInSeconds, session.userId)
            onVerified(session)
        } catch (error: AuthApiException) {
            errorMessage = error.message
        } catch (_: Exception) {
            errorMessage = "This verification link is invalid or expired. Request a new email."
        } finally {
            loading = false
            onVerificationLinkHandled()
        }
    }

    val policies = authPolicies
    val legalReady = policies?.termsUrl != null && policies.privacyUrl != null
    val canSubmit = !loading && !loadingPolicies && legalReady && adultConfirmed && termsAccepted && privacyAccepted

    Surface(modifier = Modifier.fillMaxSize(), color = RewardsTokens.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            TextButton(onClick = onBack, enabled = !loading) { Text("Back") }
            Text("PLAY & EARN REAL CASH", style = MaterialTheme.typography.labelLarge, color = RewardsTokens.accent)
            Text(
                text = if (codeRequested) "Verify your email" else "Create your account",
                style = MaterialTheme.typography.headlineMedium,
                color = RewardsTokens.text,
            )
            Text(
                text = "Use a verified email or Google account. Phone verification is requested separately before cash withdrawal.",
                style = MaterialTheme.typography.bodyMedium,
                color = RewardsTokens.muted,
            )

            if (loadingPolicies) {
                CircularProgressIndicator()
            } else if (policies == null || !legalReady) {
                Text(
                    text = "Signup is unavailable until the approved Terms and Privacy Notice are published.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = RewardsTokens.warning,
                )
            }

            if (!codeRequested) {
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it.take(255) },
                    label = { Text("Full name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it.trim().take(255) },
                    label = { Text("Email address") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                ConsentCheckbox(
                    checked = adultConfirmed,
                    onCheckedChange = { adultConfirmed = it },
                    label = "I confirm that I am 18 years of age or older.",
                )
                ConsentCheckbox(
                    checked = termsAccepted,
                    onCheckedChange = { termsAccepted = it },
                    label = "I agree to the Terms.",
                )
                policies?.termsUrl?.let { PolicyLink("Read Terms", it) }
                ConsentCheckbox(
                    checked = privacyAccepted,
                    onCheckedChange = { privacyAccepted = it },
                    label = "I have read the Privacy Notice.",
                )
                policies?.privacyUrl?.let { PolicyLink("Read Privacy Notice", it) }

                PreferenceSwitch(
                    title = "Product analytics",
                    checked = analyticsOptIn,
                    onCheckedChange = { analyticsOptIn = it },
                )
                PreferenceSwitch(
                    title = "Personalized partner offers",
                    checked = personalizedOffersOptIn,
                    onCheckedChange = { personalizedOffersOptIn = it },
                )

                Button(
                    onClick = {
                        scope.launch {
                            loading = true
                            errorMessage = null
                            try {
                                val result = api.requestEmailVerification(
                                    email = email,
                                    fullName = fullName,
                                    adultConfirmed = adultConfirmed,
                                    termsAccepted = termsAccepted,
                                    privacyAccepted = privacyAccepted,
                                    analyticsOptIn = analyticsOptIn,
                                    personalizedOffersOptIn = personalizedOffersOptIn,
                                )
                                codeRequested = true
                                linkFallback = result.deliveryMethod == "link"
                                statusMessage = if (result.deliveryMethod == "link") {
                                    "A verification link was sent to ${result.emailHint}. Open it on this device to continue."
                                } else {
                                    "A verification code was sent to ${result.emailHint}. The email also contains a one-time link fallback."
                                }
                            } catch (error: AuthApiException) {
                                errorMessage = error.message
                            } catch (_: Exception) {
                                errorMessage = "Could not start signup. Check your connection and try again."
                            } finally {
                                loading = false
                            }
                        }
                    },
                    enabled = canSubmit && !codeRequested && fullName.isNotBlank() && email.contains('@'),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    if (loading) CircularProgressIndicator() else Text("Send verification email")
                }

                Button(
                    onClick = {
                        scope.launch {
                            loading = true
                            errorMessage = null
                            try {
                                val nonce = api.requestGoogleNonce()
                                val googleOption = GetGoogleIdOption.Builder()
                                    .setFilterByAuthorizedAccounts(false)
                                    .setServerClientId(BuildConfig.GOOGLE_WEB_CLIENT_ID)
                                    .setNonce(nonce.nonce)
                                    .setAutoSelectEnabled(false)
                                    .build()
                                val request = GetCredentialRequest.Builder()
                                    .addCredentialOption(googleOption)
                                    .build()
                                val response = credentialManager.getCredential(context, request)
                                val credential = response.credential as? CustomCredential
                                    ?: throw IllegalStateException("Google did not return an ID token")
                                if (credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                                    throw IllegalStateException("Google did not return an ID token")
                                }
                                val googleToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                                val session = api.verifyGoogleCredential(googleToken, nonce.nonce)
                                tokenStore.saveAccessToken(session.accessToken, session.expiresInSeconds, session.userId)
                                onVerified(session)
                            } catch (error: AuthApiException) {
                                errorMessage = error.message
                            } catch (_: GetCredentialException) {
                                errorMessage = "Google sign-in was cancelled or unavailable."
                            } catch (_: Exception) {
                                errorMessage = "Google sign-in could not be completed. Try email verification instead."
                            } finally {
                                loading = false
                            }
                        }
                    },
                    enabled = canSubmit && !codeRequested && policies?.googleSignInEnabled == true
                        && BuildConfig.GOOGLE_WEB_CLIENT_ID.isNotBlank() && !loading,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text("Continue with Google")
                }
            } else {
                Text("Verification email sent to $email", style = MaterialTheme.typography.bodyMedium, color = RewardsTokens.muted)
                if (linkFallback) {
                    Text(
                        "Open the one-time verification link from that email on this device. The link expires after 10 minutes.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = RewardsTokens.muted,
                    )
                } else {
                    OutlinedTextField(
                        value = code,
                        onValueChange = { code = it.filter(Char::isDigit).take(6) },
                        label = { Text("6-digit email code") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Button(
                        onClick = {
                            scope.launch {
                                loading = true
                                errorMessage = null
                                try {
                                    val session = api.verifyEmailCode(email, code)
                                    tokenStore.saveAccessToken(session.accessToken, session.expiresInSeconds, session.userId)
                                    onVerified(session)
                                } catch (error: AuthApiException) {
                                    errorMessage = error.message
                                } catch (_: Exception) {
                                    errorMessage = "The code is invalid or expired. Request a new email."
                                } finally {
                                    loading = false
                                }
                            }
                        },
                        enabled = code.length == 6 && !loading,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        if (loading) CircularProgressIndicator() else Text("Verify email")
                    }
                }
                TextButton(onClick = { codeRequested = false; code = "" }, enabled = !loading) {
                    Text("Use a different email")
                }
            }

            if (!statusMessage.isNullOrBlank()) {
                Text(statusMessage.orEmpty(), style = MaterialTheme.typography.bodyMedium, color = RewardsTokens.success)
            }
            if (!errorMessage.isNullOrBlank()) {
                Text(errorMessage.orEmpty(), style = MaterialTheme.typography.bodyMedium, color = RewardsTokens.danger)
            }
        }
    }
}

@Composable
private fun ConsentCheckbox(checked: Boolean, onCheckedChange: (Boolean) -> Unit, label: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Checkbox(checked = checked, onCheckedChange = onCheckedChange)
        Text(
            text = label,
            modifier = Modifier.weight(1f).padding(top = 12.dp),
            style = MaterialTheme.typography.bodyMedium,
            color = RewardsTokens.text,
        )
    }
}

@Composable
private fun PreferenceSwitch(title: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = RewardsTokens.text)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun PolicyLink(label: String, url: String) {
    val context = LocalContext.current
    TextButton(onClick = {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }) {
        Text(label)
    }
}
