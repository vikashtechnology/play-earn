# Play &amp; Earn Real Cash

An India-first rewards marketplace for verified offers, surveys, check-ins, brand deals, products, and eligible cash rewards. The offerwall is one earning area, not the app's primary identity.

## Product summary

The app allows users to earn virtual coins through verified activities and redeem them for cash payouts, gift cards, or products under compliant, auditable flows.

## Documentation

- [prd.md](prd.md) — product requirements
- [architecture.md](architecture.md) — technical architecture
- [design.md](design.md) — UI and UX direction
- [business_model.md](business_model.md) — monetization model
- [rewards.md](rewards.md) — reward logic and catalog
- [payouts.md](payouts.md) — payout and withdrawal flows
- [brand_deals.md](brand_deals.md) — brand / partnership model
- [ads_app_promotion.md](ads_app_promotion.md) — ad and app-promotion guidance
- [compliance_play_store.md](compliance_play_store.md) — Play policy and compliance
- [mistakes_to_avoid.md](mistakes_to_avoid.md) — risk and anti-patterns
- [rules.md](rules.md) — engineering constraints
- [tasks.md](tasks.md) — delivery task plan
- [memory.md](memory.md) — project memory and decisions
- [infrastructure/README.md](infrastructure/README.md) — local services and environment setup
- [important_features_and_requirements.md](important_features_and_requirements.md) — cross-cutting product and release requirements

## Repository structure

```text
rewards-platform/
├── apps/
│   ├── android/
│   ├── admin/
│   └── api/
├── packages/
│   ├── shared-types/
│   └── validation/
├── infrastructure/
├── .gitignore
├── package.json
├── README.md
├── docs/
└── existing project docs (root-level)
```

## Current status

The API foundation currently includes health, wallet, offer, reward, payout, product, and order flows, with automated tests. Docker Compose provides a local PostgreSQL, Redis, migration, and API stack. Some feature routes still use in-memory stores and are not production persistence.

## Local environment

See [infrastructure/README.md](infrastructure/README.md) for Docker setup, environment variables, and local API commands.

## Working rules

- One task at a time from [tasks.md](tasks.md)
- No feature implementation before documentation and repo foundation are complete
- Money-changing flows must be ledgered, auditable, and validated at API boundaries
- Compliance review is part of product readiness
