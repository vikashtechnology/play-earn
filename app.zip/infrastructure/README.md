# Local Infrastructure

## Prerequisites

- Docker Desktop with Docker Compose v2
- Node.js and npm for running tests or the API outside Docker

## Connect the API to Neon

Edit the pre-created `apps/api/.env` file and replace the two PostgreSQL placeholders with connection strings from the Neon console. Use the pooled connection string for `POSTGRES_URL` and the direct connection string for `MIGRATIONS_DATABASE_URL`; both should include `sslmode=require`. URL-encode any special characters in the database password. Keep `.env` out of source control. If the file is missing, copy `apps/api/.env.example` to create it.

Then apply the schema and start the API from the repository root:

```sh
npm --workspace @rewards-platform/api run migrate
npm run dev:api
```

The API checks PostgreSQL connectivity before listening. Redis remains optional for the current API routes and can run locally or be configured through `REDIS_URL`.

Signup providers are fail-closed by default. Before enabling them, configure `EMAIL_PROVIDER_API_KEY`, `EMAIL_FALLBACK_API_KEY`, `EMAIL_FROM`, public reviewed `TERMS_URL`/`PRIVACY_URL` and their versions, then set `SIGNUP_ENABLED=true`. Google sign-in additionally requires a server OAuth web client ID and `GOOGLE_SIGNIN_ENABLED=true`; configure the same web client ID in the Android Gradle property. Email verification uses Resend in the current adapter. SMS withdrawal verification requires Fast2SMS credentials and DLT-approved templates; keep `OTP_DELIVERY_ENABLED=false` until those are ready. Never enable signup against placeholder policy URLs.

## Start the local Docker stack

The repository root `.env` is also pre-created with local Docker placeholders. Change the local passwords/secrets before starting the stack, then run:

```sh
npm run infra:up
```

Compose starts PostgreSQL and Redis, waits for their health checks, applies SQL migrations, and starts the API. The API health endpoint is available at `http://localhost:4000/api/health` by default. Host ports can be changed with `POSTGRES_PORT`, `REDIS_PORT`, and `API_PORT` in `.env`.

Useful commands:

```sh
npm run infra:logs
npm run infra:down
npm test
npm run build
npm --workspace @rewards-platform/api run smoke:identity
```

The identity smoke command requires the configured Neon database. It uses a synthetic address/phone, checks email consent creation, Google nonce replay prevention, and phone Minimum KYC, then deletes its temporary records.

The Compose stack is for local development. Do not use its default credentials or development JWT secret in a deployed environment. PostgreSQL migrations create the schema, but several current API feature routes still keep their data in process memory; a running database does not yet make those routes persistent.
